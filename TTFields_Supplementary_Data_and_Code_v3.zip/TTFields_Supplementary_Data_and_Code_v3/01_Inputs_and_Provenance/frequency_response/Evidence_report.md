# Reviewer 2 — Comment 2: primary 17-cell-line frequency-response evidence

**21 November 2026 | Source audit only | Frozen cohort unchanged**

## Decision

All 17 label-defining frequency-scan panels were located in the 12 source publications or their supplied supplements. No complete downloadable author-supplied numerical curve or replicate-level frequency-response dataset was verified in the materials accessible during this audit. This does **not** establish that no such dataset exists. Several supplementary downloads could not be independently retrieved; the inventory identifies them. Figure digitization is feasible, but digitization was not performed here; the numeric response fields contain only explicitly reported author summaries (or transparent arithmetic conversions of those summaries).

The strongest immediately defensible alternative requested by the reviewer is a common-grid sensitivity cohort of seven cell lines from four publications. Its shared grid and endpoint are independently verified from original figures, not inferred from frequency ranges.

## Source-by-source evidence and digitization targets

Frequencies below exclude the untreated control. The full-page excerpts contain original figure captions, pagination and attribution. The CSV includes the untreated comparator as frequency 0 only for bookkeeping; it is not an exposed frequency. Blank response and variability cells are missing, not zero.

| Cell line(s) | Source/panel | Applied kHz | Endpoint / time | Availability |
|---|---|---|---|---|
| MDA-MB-231 | Kirson 2007 Fig. 2B, p. 10153, square series | 50, 100, 150, 200, 300, 500 | XTT-derived relative cell number, 24 h | Plot only; variance type not stated |
| A2780; OVCAR-3; Caov-3 | Voloshin 2016 Fig. 1a,b,c p. 2853 | 100, 150, 200, 300, 400 | Cell number, 72 h | 200-kHz mean summary; other values plot only; SEM, general n ≥3 |
| HCC4006 | Karanam 2017 Supplementary Fig. 1A lower middle, Table 1 | 100, 150, 200 | Cell count, 0/24/48/72 h | Table 1 gives 69% inhibition at 150 kHz, N=3; graph has time-specific bars; error-bar type unspecified |
| MSTO-211H | Mumblat 2021 Fig. 1A top row p. 102 | 100, 150, 200, 400 | Cell count, 72 h | Plot only, SEM; general n ≥3 |
| KNS42; DAOY | Branter 2022 Fig. 1A GBM and medulloblastoma panels | 100, 200, 300, 400 | PrestoBlue relative metabolic viability, 72 h | Plot only; exact scan n and error type unspecified |
| AGS; KATO III | Fishman 2026 Fig. 1A top/bottom p. 5 | 100, 150, 200, 300, 400 | Cell count, 72 h | Selected-point means only; SEM, general n ≥3 |
| HepG2 | Davidi 2022 Fig. 1a top p. 6 | 100, 150, 200, 300, 400 | Cell count, 72 h | 150-kHz mean ± SEM; n ≥3 |
| AsPC-1 | Giladi 2014 pancreatic Fig. 1A red triangles p. 57 | 100, 150, 200, near 240, 300 | Cell count, 72 h | 150-kHz mean reported; near-240 point lacks explicit nominal frequency label |
| HCC827; NCI-H520 | Giladi 2014 lung Fig. 1A p. S37 (H520 is HTB-182, https://www.atcc.org/products/htb-182) | 100, 150, 200, 240 | XTT-based relative viability, 72 h | Plot only; ambiguous source wording for SD; scan n unspecified |
| GaMG | Kessler 2018 Fig. 1A p. 3, yellow circles | 100, 200, 300, 400 | Cell count, 72 h | Plot only; n=1, no scan variability. Fig. 1D is a distinct replicated experiment |
| MES-SA | Koltun 2025 Supplementary Fig. S1F | 100, 150, 200, 300, 400 | Cell count (cytotoxicity proxy), 72 h | Plot only; SEM, exact n unspecified |
| RBE | Yue 2025 Fig. 1A right p. 3 | 100, 150, 200 | Cell count, 96 h | 150-kHz mean 48.0% of control; SD, n=6; authors report no significant between-frequency differences |

## Numerical anchors and limitations

There are 93 primary-scan records (including 17 controls), and 129 records after retaining separate timepoints, endpoints and reported single-point summaries. Eight primary-scan values are available numerically in the publication text/caption: A2780 23%, OVCAR-3 30%, Caov-3 25% (100 minus explicitly reported reductions); AGS 53%, KATO III 57%, HepG2 40.0 ± 3.8%, AsPC-1 65 ± 3%, RBE 48.0% of control. These are summaries, not replicate observations. HCC4006 Table 1 additionally supplies 69% inhibition at 150 kHz, stored separately from the plotted bar. Five ancillary numerical records are included in total.

AsPC-1 has a source-internal variability discrepancy: Fig. 1 caption reports 65 ± 3% of control, whereas Results §3.1 reports 35 ± 10% reduction. The central value is consistent; uncertainty is not. Both are recorded separately. Branter's KNS42 and DAOY cell-count reductions at the selected frequency (61% and 30%) belong to Fig. 1B, not the PrestoBlue scan in Fig. 1A. Mumblat's 56.8 ± 5.1% for MSTO originates from Fig. 1D, not 1A. No figure-only response or error-bar length was estimated and represented as original data.

Koltun main Fig. 1C and 1E measure percentage of 7-AAD-positive cells in A2780 and MES-SA after 24 h. S1D measures MES-SA 7-AAD MFI fold change in the same experiments, not percentage-positive or 72-h cell counts. S1D shows an extra unlabelled point near 50 kHz despite the stated range of 100–400 kHz; its frequency is unresolved and marked approximate. None of these permeability records are used to define the primary grid. Clonogenic assays in several papers were at a selected setting; they are not substitutes for a full scan of the primary endpoint. Branter Fig. 2 is DBS in Hz, not TTFields in kHz.

## Exactly shared primary grids

| Applied kHz | n | Cell lines | Endpoint / duration comparability |
|---|---:|---|---|
| 100,150,200,300,400 | 7 | A2780, OVCAR-3, Caov-3, AGS, KATO III, HepG2, MES-SA | All relative cell counts after 72 h; four studies. MES-SA uses count as a cytotoxicity proxy. |
| 100,200,300,400 | 3 | KNS42, DAOY, GaMG | PrestoBlue for first two, count for GaMG; 72 h. Do not combine the response scale. |
| 100,150,200 | 2 | HCC4006, RBE | Cell counts; 72 vs 96 h; both selected at 150 kHz. |
| 100,150,200,240 | 2 | HCC827, NCI-H520 | Same assay, source and 72 h; both labels 150 kHz. |

MSTO-211H (100,150,200,400) and MDA-MB-231 (50,100,150,200,300,500) have unique verified grids. AsPC-1 is separately listed because the near-240-kHz setting is not explicitly labelled. Its exact grid cannot be certified. No grid is defined from a continuous range alone.

The seven-line common-grid group has one 100-, three 150-, and three 200-kHz labels. Within each of the four source publications, the selected label is constant. It therefore supports a descriptive common-grid check, not identification of a within-study label effect. Common endpoints and durations do not guarantee equivalent field intensities, exposure protocols, biological lineage or study independence. No molecular or correlation analyses were performed.

## Unavailable data and next step

See Source_inventory.csv for all twelve source-specific availability determinations, including the verified supplemental panels and uninspected files. The Branter supplement ZIP, Fishman supplementary tables/data sheet, Kessler supplemental image/legend, Yue supplement, and Kirson SI were not successfully downloaded for independent complete inspection in this audit. Davidi's S2 is a rat scan, not a HepG2 source-data table. Koltun explicitly states that data are available from the corresponding authors on request, as does Yue. A full numeric curve analysis would need author-supplied means and preferably replicates, or separately validated/calibrated digitizations recorded as digitized (not original numerical). It cannot be claimed completed from these anchor values.

**Recommendation:** Answer the reviewer's common-grid alternative with the verified seven-line restriction, retaining all 17 in the primary cohort. If full-curve analysis remains desirable, prioritize author data requests and subsequently independently digitize the original figure panels for any still-missing curve means and error bars. No cohort, selected-frequency label, manuscript or molecular results were modified.

## Package notes

- TTFields_R2_FrequencyResponse17.csv: long-format inventory; filter record_role = primary_scan for the label-defining curves. Other records are separate endpoint/timepoint summaries.
- Common_grid_inventory.csv: full-set comparisons; near-240 point explicitly unresolved.
- Source_inventory.csv: DOI, source locations, access/availability, and local evidence file references.
- source_pages/: relevant full-page PDF excerpts from the original supplied publications and the supplied Koltun supplementary figure image. Karanam supplementary figure is reproduced by rendering the supplied DOC. Original authors and publication attribution are retained; intended for private source verification, not unrestricted republication.
