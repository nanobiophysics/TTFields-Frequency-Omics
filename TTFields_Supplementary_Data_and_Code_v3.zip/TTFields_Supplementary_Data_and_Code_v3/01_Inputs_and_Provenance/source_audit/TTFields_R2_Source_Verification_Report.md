# TTFields frekans etiketlerinin kaynak doğrulaması

Reviewer 2 – Comment 2 | 20 Kasım 2026

## Kapsam ve değerlendirme yöntemi

Table 1'deki 26 hücre hattının 12 kaynak makalesi, Karanam 2017 Supplementary Figure 1 ve Koltun 2025 Supplementary Figure S1 üzerinden incelendi. Excel dosyasında orijinal 20 hücre hatlık kohort işaretlenmiştir. Ayrık frekanslar yalnızca grafik veya metinde doğrulanabildiğinde listelenmiştir. 0 kHz/untreated control frekans setinden çıkarılmıştır. Kaynak tarafından belirtilen frekans etiketi korundu; grafik ile tutarsızlık bulunduğunda ayrıca belirtildi. Kontrol karşılaştırmaları, komşu frekanslarla doğrudan karşılaştırmalardan ayrı kaydedildi. Grafiklerden sayısal değer tahmin edilmedi.

## En önemli kaynak bulguları

- **Kirson 2007:** MDA-MB-231'in Figure 2B eğrisi mevcut; U-118 MG ve U-87 MG için 200 kHz metin içinde bildiriliyor, ancak ayrı tarama eğrileri yok. Kessler 2018 U-87 MG için 200 kHz'i destekliyor, ancak tek tarama deneyi (n = 1) kullanılmış. Hücre hattı kimliği sorunu devam ediyor.
- **Karanam 2017:** Supplementary Figure 1, tek bir ortak tarama seti bulunmadığını gösteriyor. H157 ve HCC4006 için 100, 150, 200 kHz; A549, H1299 ve H1650 için 100, 200, 300 kHz gösterilmiş. Table 1 H1650 için 100 kHz bildiriyor, fakat Figure S1'de 72 saatlik ortalama hücre sayısı 300 kHz'de görsel olarak daha düşük görünüyor. Bu uyuşmazlık doğrulanmadan etiketi değiştirmemeli; kaynak yazarından sayısal veri veya açıklama talep edilmeli. H157 için 100 ve 200 kHz, A549 için 200 ve 300 kHz görsel olarak yakın. Grafik hata çubukları komşu frekans üstünlüğü kanıtı değildir.
- **Koltun 2025:** S1F, MES-SA için 100 kHz'in hücre sayısı temelli sitotoksisite etiketini ve 100, 150, 200, 300, 400 kHz taramasını doğruluyor. S1D'deki 150 kHz sonucu membran geçirgenliği endpoint'ine ait; farklı bir fenotip. S1F'de doğrudan istatistiksel karşılaştırma veya deney sayısı verilmemiştir.
- **Voloshin 2016, Fishman 2026 ve Davidi 2022:** Grafiklerde 100, 150, 200, 300, 400 kHz ortak seti doğrulanmıştır. Belirtilen anlamlılık kontrole göredir. Mumblat 2021 H2052 aynı seti kullanırken MSTO-211H'de 300 kHz yoktur.
- **Yue 2025:** RBE için 150 kHz sayısal minimumdur; kaynak üç frekans arasında anlamlı fark olmadığını açıkça bildiriyor. Bu durum kaynağa özgü frekans etiketi ile istatistiksel üstünlük arasındaki farkı gösterir.
- **Branter 2022 ve Kessler 2018:** 100, 200, 300, 400 kHz ortak seti bulunur. Branter'da seçilen frekanstaki hücre sayısı kontrol ile karşılaştırılmıştır; frekans eğrisi metabolik canlılık temellidir. Kessler'da frekans taraması n = 1'dir.

## Ortak frekans setleri ve duyarlılık analizi

| Tam frekans seti (kHz) | Orijinal kohort | Seçilmiş frekans dağılımı | Değerlendirme |
|---|---:|---|---|
| 100, 150, 200, 300, 400 | 8 | 100: 1, 150: 4, 200: 3 | En geniş aday alt kohort; beş kaynak çalışma. H2052 çıkarıldığında n=7. |
| 100, 200, 300, 400 | 4 | 200: 3, 300: 1 | Yalnız CNS, iki kaynak çalışma; DAOY olmadan etiket varyasyonu yok. |
| 100, 150, 200, 240 | 2 | 150: 2 | Etiket varyasyonu yok. |
| Diğer ayrı setler ya da doğrulanmamış grid | 6 | Tekil gruplar | Korelasyon için yeterli değil. |

Mevcut sabit kompozit skorla keşifsel ortak-grid kontrolleri (orijinal etiketler korunarak):

| Alt kohort | n | Spearman ρ | Nominal p |
|---|---:|---:|---:|
| Beş frekanslı ortak set | 8 | 0.574 | 0.137 |
| Beş frekanslı ortak set, H2052 hariç | 7 | 0.849 | 0.0157 |
| Dört frekanslı CNS ortak seti | 4 | 0.775 | 0.225 |

Beş frekanslı grupta her kaynak çalışma tek bir selected-frequency seviyesine sahiptir; dolayısıyla çalışma içi frekans etkisi tanımlanamaz. Dört frekanslı grupta da farklı etiketler yalnız Branter 2022'de bulunur ve DAOY çıkarıldığında korelasyon tanımsızdır. Nominal p değerleri çalışma kümelenmesi ve post hoc kompozit seçimine göre düzeltilmemiştir. Ortak grid incelemesi, farklı endpoint, deney koşulu, lineage ve seçimin belirsizliğini ortadan kaldırmaz. Sonuçlara bakarak kohort seçimi yapılmamalıdır.

## Hakeme yönelik sonuç

Kaynak incelemesi, etiketlerin test edilen ayrık frekanslar arasındaki kaynak- ve endpoint-bağımlı seçilmiş frekanslar olarak yorumlanması gerektiğini destekler. Tam eğriler çoğu makalede grafik biçimindedir. Ham tekrar düzeyindeki veriler incelenen dosyalarda bulunmadığı için grafik sayısallaştırması yalnızca yaklaşık ortalama eğrilerini sağlayabilir; bunlardan komşu frekansların istatistiksel üstünlüğü güvenilir şekilde yeniden test edilemez. Ortak-grid duyarlılık analizi ve DAOY dışlama analizi hakeme sunulabilir, ancak kesin birincil kohort ve analizler Reviewer 2 Comment 7 ile birlikte tutarlı olarak belirlenmelidir.

Ana makalede ve Response Letter'da bu aşamada değişiklik yapılmamıştır.
