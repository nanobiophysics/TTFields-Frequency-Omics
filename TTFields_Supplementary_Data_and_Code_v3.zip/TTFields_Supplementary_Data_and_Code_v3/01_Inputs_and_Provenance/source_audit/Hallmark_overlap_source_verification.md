# Hallmark Angiogenesis–EMT gene membership verification

Scope: independent check of public human MSigDB Hallmark definitions, accessed 23 November 2026 (current release 2026.2.Hs). This is not identification of the upstream gene-set release used to generate DepMap Public 24Q2 precomputed ssGSEA scores.

| Gene set | MSigDB systematic identifier | Unique human gene symbols |
|---|---|---:|
| HALLMARK_ANGIOGENESIS | M5944 | 36 |
| HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION | M5930 | 200 |

Method: matched the human gene-symbol membership lists displayed in the two official MSigDB cards, using exact symbol equality. Intersection: 12 symbols; 33.33% of the Angiogenesis set and 6.00% of the EMT set. This is membership overlap only; it does not quantify the contribution of shared genes to ssGSEA scores or the composite association. No score, cohort, or frequency label was changed.

Shared symbols: COL3A1, COL5A2, CXCL6, FSTL1, ITGAV, LUM, MSX1, POSTN, SPP1, TIMP1, VCAN, VEGFA.

Sources (MSigDB, CC BY 4.0):

- Angiogenesis: https://www.gsea-msigdb.org/gsea/msigdb/human/geneset/HALLMARK_ANGIOGENESIS.html
- EMT: https://www.gsea-msigdb.org/gsea/msigdb/human/geneset/HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION.html
- Release documentation: https://docs.gsea-msigdb.org/MSigDB/Release_Notes/MSigDB_2026.2.Hs/
- Hallmark reference: Liberzon et al. (2015), PMID 26771021, DOI 10.1016/j.cels.2015.12.004.

Limitation: the exact upstream MSigDB version and ssGSEA configuration for the supplied 24Q2 score matrix remain undocumented. The current membership check must not be presented as verification of that historical configuration.
