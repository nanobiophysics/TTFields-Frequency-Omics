# Upstream ssGSEA provenance clarification

The supplied pathway scores are the precomputed DepMap Public 24Q2 dataset, comprising 31,117 gene sets including 50 Hallmark signatures. DepMap Community Forum documentation dated 4 March 2025 indicates that MSigDB v7.2 was likely used. This statement is qualified; the exact upstream gene-set release and ssGSEA implementation settings could not be independently verified from the supplied files. No undocumented implementation, normalization, or other parameter values are assigned.

Source: [Metadata for ssGSEA pathways](https://forum.depmap.org/t/metadata-for-ssgsea-pathways/4028), response by Phil Montgomery on 4 March 2025, accessed 24 November 2026.

The independent membership comparison in `Hallmark_overlap_source_verification.md` uses human MSigDB v2026.2.Hs. It is not a reconstruction of the historical 24Q2 score-generation configuration. The archived scores and all analytical results remain unchanged.
