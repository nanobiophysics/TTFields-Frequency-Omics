# Reviewer 2 Comment 2 – Verified source anchors (2026-11-21)

Seven selected-frequency response points were verified directly from primary articles, without graph digitization. Percent inhibition = 100 – published cell count percent of untreated control. This conversion is purely arithmetic; the underlying outcome is a source-reported cell-count endpoint, *not* a common-grid response curve.

**Critical:** Branter et al. Figure 1A frequency selection uses PrestoBlue *metabolic viability*, whereas the source prose quantifies cell-count reduction at the selected frequency. These endpoints **must not be treated as identical**. The Branter anchor points do not serve as numeric values for Figure 1A frequency-screening curves.

**Coverage:** 7 of 17 cell lines have a directly reported selected-frequency anchor point in this verification. None of the 17 has a verified complete set of numeric measurements at all tested frequencies in the currently assembled analysis archive. Graph-only curves can potentially be digitized with documented uncertainty or obtained from authors; not yet done.

**Sources:** Voloshin et al. 2016 https://doi.org/10.1002/ijc.30406; Branter et al. 2022 https://pmc.ncbi.nlm.nih.gov/articles/PMC8880247/; Fishman et al. 2026 https://doi.org/10.3389/fonc.2026.1575083.

**Submission recommendation:** Do not claim full-curve analysis is completed. Protect the n=17 primary cohort and original outcomes pending exact grid / endpoint re-verification. Do not replace graph-specified outcomes with these selected-frequency anchor points.
