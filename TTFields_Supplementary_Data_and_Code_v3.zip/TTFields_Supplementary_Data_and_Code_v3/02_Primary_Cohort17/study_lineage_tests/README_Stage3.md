# TTFields Omics, cleaned primary n=17: Stage 3 exploratory sensitivity audit
Date: 2026-11-21.

## Sources and cohort
- Original `TTFields_Supplementary_Data_and_Code_v1(7).zip` (Omics, NOT PMB computational bioimpedance).
- Frozen Stage1 `cohort_primary_17.csv` and `composite_scores_17.csv`.
- Original 24Q2 gene-set candidate rows from `TTFields_expanded_data_20261015_210436(1).zip`, including RBE and 31,117 signatures. Data matrix contains 35 candidate models, but tests use exclusively the frozen n=17.
- 24Q2 reference statistics `hallmark_reference_stats_1517.csv`.
- 17-line molecular model input from Stage2.

## Newly computed results
- Composite Spearman rho 0.696803; nominal p 0.001882.
- Binary CNS/non-CNS rank-residualized Pearson r 0.507775 (exploratory).
- Detailed lineage-adjusted rank-residualized Pearson r 0.310685, with **TEN lineage categories after addition of RBE (biliary)**. These residualized coefficients have NO robust valid inferential p-values.
- Study-within centered slope 0.174962 composite score per 100 kHz, **entirely identified by one study (Pediatric_2022, KNS42 and DAOY)**; should not be interpreted as generalizable study-adjusted association.
- Only two distinct exact study-preserving frequency allocations; nominal study-permutation p of the fixed four-signature score = 0.5.
- Re-selecting the top four positively correlated Hallmark signatures in each permutation gives an observed selection-aware correlation 0.688442 and exact p=1.0 (two admissible allocations).
- HALLMARK_SPERMATOGENESIS exact study-permutation p=0.5 and 50-Hallmark maxT FWER adjusted p=0.5.
- Global family 31,117 gene sets: exact single-step maxT minimum adjusted p=0.5; no familywise significant gene set. The HALLMARK_SPERMATOGENESIS global-family maxT p=1.0; do not confuse with 50-Hallmark maxT p=0.5.
- New nested study-grouped Ridge comparisons on n=17, fixed alpha grid (0.1,1,10,100); for molecular models absolute training-only Spearman top k = 3,5,10. Training-fold selection for reselected four-component composite, separate CNS and ten-category representations. See output CSV and code. M4 (fixed full-dataset post hoc composite) is leakage-prone and not a valid independent prediction estimate. This new comparative pipeline is NOT claimed to exactly reproduce the earlier n=20/n=18 lineage modeling, because original supplemental Table S5 evaluation specifications differed.

## Interpretation and restrictions
Results are exploratory and sensitive to study/lineage confounding, unequal frequency sampling, only one study with within-study frequency variation, and low sample size. No robust study-independent evidence is established. Genotype or mechanism inference is not justified by naming a Hallmark feature. The original 20-cell-line results remain archival/sensitivity, not primary. Model comparison has not yet been incorporated into manuscript figure/table exports. Original code/data version and source provenance should be frozen and versioned before resubmission.
