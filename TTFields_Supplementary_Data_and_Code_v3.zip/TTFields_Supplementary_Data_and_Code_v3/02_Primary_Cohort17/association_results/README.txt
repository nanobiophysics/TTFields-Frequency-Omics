TTFields R2 cohort17 Stage 1 (2026-11-21)

Source: TTFields_Supplementary_Data_and_Code_v1(7).zip; TTFields_expanded_data_20261015_210436(1).zip; Omics_R2_Comment10_CrossRelease_Audit.zip; WORK provenance assessment.

Eligibility: drop U-87 MG / ACH-000075, NCI-H2052 / ACH-000153, NCI-H1650 / ACH-000035 and U-343 MG / ACH-000036; add RBE / ACH-001856 at 150 kHz (Yue 2025). Other original n=20 records retained. The 26-row table includes 9 excluded models.

Validated source data: 17 models found in expanded 24Q2 ssGSEA dataset; RBE found in reference 24Q2 and 26Q3 expression. Study groups=12. Gene standardization uses reference mean and sample SD independently for each release; module scores average z scores. Hallmark composite uses frozen original four components and 1517-model Hallmark reference means and sample SD. Correlations use scipy.stats.spearmanr; screen nominal p uses t approximation, BH within separate test families. Within-study exact p enumerates label permutations within studies; only 2 assignments.

IMPORTANT: This is a preliminary association/eligibility audit, not a completed full R2 revision. The all-31,117 set screening and 50-Hallmark screening are verified, but post hoc selection-aware maxT, bootstrap, lineage controls, LO(S)O, predictive model re-training, figures, manuscript text and independent source PDF verification are NOT provided here. Hallmark FDR q=.0030 does NOT establish significance after accounting for selection/study structure; interpretations must be cautious.
