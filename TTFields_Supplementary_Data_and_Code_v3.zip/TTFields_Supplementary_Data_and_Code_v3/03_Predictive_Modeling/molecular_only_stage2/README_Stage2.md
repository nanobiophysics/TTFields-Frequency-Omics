# TTFields Omics — cleaned 17-line cohort Stage 2 audit

Inputs: original 20-line analysis input from TTFields_Supplementary_Data_and_Code_v1(7).zip, frozen cohort_primary_17.csv from Stage1, and RBE 50 Hallmark 24Q2 scores from TTFields_expanded_data_20261015_210436(1).zip. Raw Hallmark values for all original 20 lines exactly matched expanded data (max absolute difference = 0). No PMB data used.

Nested study-grouped regression and classification reproduce the original supplied modeling code with exactly the revised n=17 cohort, 12 unique study groups, all original model and feature grids and split methods unchanged. 300kHz DAOY is excluded for classification (n=16). This is retrospective internal evaluation, not independent validation.

The stage 2 package includes all predictions, feature selections, inner tuning searches, fold diagnostics, code and metrics. The post hoc four-signature composite is NOT a feature in the predictive model; it is separately evaluated using leave-one-line/study-out and cluster bootstrap. Study bootstrap percentile interval is descriptive only (some resamples may be degenerate) and does not solve study confounding.

NOT FINISHED: complete lineage-adjusted models and extended model comparison, selection-aware full-gene-set maxT permutation, all figures, final manuscript and response edits. This package is an auditable interim result, not submission-ready supplementary material.
