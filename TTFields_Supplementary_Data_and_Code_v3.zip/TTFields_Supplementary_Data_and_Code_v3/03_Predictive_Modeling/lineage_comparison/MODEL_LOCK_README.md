# TTFields Omics — Modeling decision lock v1 (21 November 2026)

## The decision
**Use Stage3 `PRIMARY_comparable_nested_LOSO_models_17.csv` as the SINGLE primary model-comparison family.** It compares binary CNS/non-CNS and ten-category tumor lineage models under the same outer and inner leave-one-study-out splits, Ridge regression (alpha 0.1,1,10,100), and training-only feature selection; see primary_comparison_code.py for full executable specification.

Stage2 original numerical Ridge reconstruction (k=2,3,5,10,50; alpha=100,10,1,0.1,0.01) is **supplementary methodological sensitivity only**, *not* to be numerically compared in the primary model-comparison table. Comment11 ordinal-coded regression is a separate supplementary sensitivity, not a true proportional-odds estimator.

## Primary comparison (n=17, 12 source study groups; all MAE kHz)
| status                         | representation   | model                          |   n |   MAE_kHz |   RMSE_kHz |   baseline_MAE_kHz |   baseline_RMSE_kHz |
|:-------------------------------|:-----------------|:-------------------------------|----:|----------:|-----------:|-------------------:|--------------------:|
| PRIMARY COMPARATIVE            | CNS              | lineage_only                   |  17 |    26.458 |     38.406 |             26.471 |              46.967 |
| PRIMARY COMPARATIVE            | CNS              | molecular_only                 |  17 |    37.611 |     46.554 |             26.471 |              46.967 |
| PRIMARY COMPARATIVE            | CNS              | lineage_plus_hallmark          |  17 |    32.563 |     42.773 |             26.471 |              46.967 |
| LEAKAGE-PRONE descriptive only | CNS              | lineage_plus_fixed_composite   |  17 |    31.152 |     40.922 |             26.471 |              46.967 |
| PRIMARY COMPARATIVE            | CNS              | lineage_plus_training_selected |  17 |    34.893 |     45.130 |             26.471 |              46.967 |
| PRIMARY COMPARATIVE            | Lineage          | lineage_only                   |  17 |    25.200 |     37.726 |             26.471 |              46.967 |
| PRIMARY COMPARATIVE            | Lineage          | lineage_plus_hallmark          |  17 |    29.746 |     37.161 |             26.471 |              46.967 |
| LEAKAGE-PRONE descriptive only | Lineage          | lineage_plus_fixed_composite   |  17 |    26.725 |     35.237 |             26.471 |              46.967 |
| PRIMARY COMPARATIVE            | Lineage          | lineage_plus_training_selected |  17 |    28.479 |     36.486 |             26.471 |              46.967 |

### Reporting rules
- The same training-median baseline is MAE **26.47 kHz** for the Stage3 primary comparisons.
- The **ten-lineage-only** model has lowest MAE among the reported non-leakage models: **25.20 kHz**, compared with **37.61 kHz molecular-only** and **29.75 kHz lineage+Hallmark** (ten-lineage).
- The **lineage+fixed four-composite** is selected on full cohort and **has selection leakage**; do not claim this MAE is independently validated. Label exploratory/descriptive only or omit from main text.
- Training-selected composite within folds is a different estimand from original post hoc fixed composite; no replicated independent validation inferred.
- Stage2 molecular-only MAE **31.46 kHz** belongs to a DIFFERENT reconstructed design and cannot be contrasted directly with Stage3 lineage-only MAEs.
- Classification n=16 (300 kHz singleton omitted) is separate from regression n=17.
- All Stage3 models are post hoc and underpowered. Full methodological details and complete code must be deposited; selected hyperparameter grid was set for this comparative reconstruction.
- Study count 12; individual observations within study are not independent sources of external evidence.
- This lock fixes **model comparison reporting only**. It is NOT a new recomputation of underlying model outputs or a claim that lost original code was recovered.

## Mapping to manuscript
- Section 2.4: explain the comparative nested LOSO design + baseline + within-fold feature selection, distinguish fixed from reselected composites.
- Section 3.6: report primary comparator MAEs from this single CSV (not Stage2), state no consistent molecular predictive advantage.
- Supplementary Table S5: rebuild from this CSV and explicitly flag leakage-prone fixed composite; ordinal sensitivities go in a separate table.
- Reviewer 1 lineage questions, Reviewer 2 comments 9/11: same definitions and figures.

## Remaining final checks before manuscript freeze
Verify code execution and software dependencies, align model code across published archive, set all reproducibility seeds, inspect Figure 4 design, and check input mapping; no more exploratory analyses unless a defect in verified code requires correction.
