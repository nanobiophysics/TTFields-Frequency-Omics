# v3 revision consolidation — 24 November 2026

- Updated `02_Primary_Cohort17/association_results/provenance_26_primary17_decisions.csv`: 11 former range displays reconciled with revised Table 1, three footnote labels corrected, and source figure/page locators and uncertainty notes populated for all 26 curated lines. The approximately 240 kHz AsPC-1 point is explicitly qualified in the source metadata; it is not treated as an exact shared-grid setting. Selected-frequency labels, Model IDs, cohort inclusion decisions and exclusion justifications are unchanged.
- Retained the historical `01_Inputs_and_Provenance/frequency_extraction_26.csv` and all historical archives without modification.
- Added source-attributed Hallmark Angiogenesis–EMT membership documentation and qualified upstream ssGSEA provenance information.
- Extended replay validation to compare all recorded lineage and ordinal held-out predictions directly against previous replay outputs. The numerical analyses were not changed.
- Retained all four final figures in 600-dpi PNG and vector PDF formats; no redraw or replacement of scientific content.
- Updated README and recalculated SHA256 file integrity records for all packaged files.

No new cohort selection, model fitting, molecular screening or frequency-label reassignment was undertaken for v3. The output records are unchanged from v2. Public repository deposition and DOI assignment occur separately.
