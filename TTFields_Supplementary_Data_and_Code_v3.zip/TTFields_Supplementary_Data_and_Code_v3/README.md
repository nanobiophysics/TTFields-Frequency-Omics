# TTFields Supplementary Data and Code v3

**Final revision archive (24 November 2026).** This release retains the frozen numerical results of v2. Source metadata have been reconciled with the revised Table 1 and the source-verification workbook; the historical extraction and original analysis snapshots remain unchanged. The current MSigDB membership verification and an upstream provenance note are provided in `01_Inputs_and_Provenance/source_audit/`. See `CHANGELOG_v3.md` for the specific changes.

**Scope:** revised manuscript, exploratory analysis of literature-derived selected-frequency labels and independently generated baseline molecular profiles. Primary cohort: 17 human cancer cell lines from 12 source publications / analytical study groups. Historical initial cohort: 20 cell lines from 11 groups. The 17-cell-line cohort is not a simple subset of the initial cohort: four cell lines were excluded following provenance review and RBE was added. No cohort or frequency label was changed during this archival consolidation.

## How to navigate

| Directory | Contents |
|---|---|
| 01_Inputs_and_Provenance | Curated frequency records; source verification workbook and report; source figure/endpoint/frequency inventory and response-data availability ledger; expanded 24Q2 ssGSEA candidate matrix (35 candidate models including all 17 primary and all 20 historical models); 50-Hallmark reference matrix and statistics; 24Q2 and 26Q3 targeted expression reference subsets; conventional characteristics and module definitions. Candidate presence does not imply eligibility. |
| 02_Primary_Cohort17 | Frozen cohort, eligibility ledger, target-gene/module results for both releases, 31,117 and 50 gene-set screens, composite scores, within-study exact permutations, rank-residualized lineage analysis and global max-T. |
| 03_Predictive_Modeling | Two distinct numerical pipelines and a separate ordinal-coded sensitivity. The molecular-only pipeline supplies Figure 4; the common comparative lineage-aware pipeline supplies Supplementary Table S5. Fold-level results, tuning, and held-out predictions included. |
| 04_Sensitivity_Analyses | Verified common-grid subset of seven lines, four source studies, and study-exclusion comparison (Table S6). |
| 05_Original_Cohort20_and_Secondary18 | Initial submission archive and retrospective revision audits for historical 20- and 18-line cohorts. These are provenance/secondary comparisons, not current primary results. Older README statements and historical absolute paths are preserved within these snapshots. |
| 06_Figure_Generation | Final Figures 1–4 (600-dpi PNG and vector PDF) and executable plotting scripts. |
| 07_Reproducibility | Requirements, portable analysis replay scripts, validation record, and methodology clarification. |

### Authoritative result mapping

| Manuscript location | Result file(s) |
|---|---|
| Table 1, Table S1, Figure 1 | 02_Primary_Cohort17/association_results/provenance_26_primary17_decisions.csv; 01_Inputs_and_Provenance/frequency_extraction_26.csv (historical extraction; use revised provenance for current eligibility) |
| Table S4 | 02_Primary_Cohort17/association_results/cohort_primary_17.csv; RBE source group is Yue_2025 |
| Section 3.2 | 01_Inputs_and_Provenance/conventional_features_sources.csv; verify_associations.py |
| Section 3.3, Table S3 | genes_26_*_17.csv and modules_7_*_17.csv in association_results; module definitions in 01_Inputs_and_Provenance |
| Section 3.4, Figure 2 | global_ssgsea_screen_17.csv, hallmark_screen_17.csv, global_31117_exact_maxT_17.csv |
| Section 3.5, Figure 3 | composite_scores_17.csv; study_lineage_tests; molecular_only_stage2/robustness (LOSO, LOCO, bootstrap) |
| Table S2 | cohort17 fixed-composite result and historical v1 annotation sensitivity results |
| Section 3.6, Figure 4 | 03_Predictive_Modeling/molecular_only_stage2/model17/metrics.json and predictions |
| Section 3.6, Table S5 | 03_Predictive_Modeling/lineage_comparison/PRIMARY_comparable_nested_LOSO_models_17.csv |
| Section 3.6, ordinal sensitivity | 03_Predictive_Modeling/ordinal_and_replay/ordinal_model_comparison_17.csv |
| Table S6 | 04_Sensitivity_Analyses/common_grid/correlation_and_study_sensitivity.csv |

## Reproduce primary results

Use Python 3.12.14 and the pinned versions in 07_Reproducibility/requirements.txt. From the extracted archive root:

```sh
python -m pip install -r 07_Reproducibility/requirements.txt
python 07_Reproducibility/verify_associations.py
python 07_Reproducibility/reproduce_stage3_lineage_and_hallmark.py
python 07_Reproducibility/reproduce_stage3_global_maxT.py
python 07_Reproducibility/molecular_only.py
python 07_Reproducibility/lineage_comparison.py
python 07_Reproducibility/ordinal_sensitivity.py
python 07_Reproducibility/verify_replays.py
python 06_Figure_Generation/draw_figure1_cohort17.py
python 06_Figure_Generation/draw_figures23_cohort17.py
python 06_Figure_Generation/draw_figure4_cohort17.py
```

Scripts write to a new `rerun/` directory; frozen results are unchanged. Verification was executed using Python 3.12.14, NumPy 2.3.5, pandas 2.2.3, SciPy 1.17.0, scikit-learn 1.8.0 and Matplotlib 3.10.8. The study-cluster bootstrap uses seed 20261121 and 10,000 draws (9,928 valid). Historical archives are supplied as evidence of the earlier analysis, not asserted to be a fully portable replay of lost original code. The reconstructed initial pipeline does not establish recovery of the unavailable original implementation.

## Reporting and inferential limits

- Selected-frequency labels are source- and endpoint-dependent greatest reported inhibition among tested frequencies, not established biological optima. The source-response ledger distinguishes author-supplied anchor values from graphical-only / unavailable measurements; it does not contain reconstructed or invented full curves. Source PDFs and article images are not redistributed here; use the DOI, figure and page references in the inventory. Raw source PDFs can be retained by the author separately.
- The upstream 460.9 MB gene-expression file is not needed to reproduce the reported targeted 26-gene analyses. The reference subsets contain the relevant columns. The expanded ssGSEA candidate subset contains all required rows and all 31,117 gene sets. DepMap Community Forum documentation suggests MSigDB v7.2 was used for the precomputed 24Q2 scores; the exact upstream gene-set release and ssGSEA implementation settings could not be independently verified. The separate membership check uses human MSigDB v2026.2.Hs and does not verify the historical configuration. Cross-release comparison covers targeted genes and replication modules, not ssGSEA cross-release stability.
- One study contributes within-study frequency variation; the exact permutation space contains two assignments. FDR significance in the separately evaluated 50-Hallmark family does not establish an association independent of study or tumor lineage.
- The original four components were selected after examination of the initial 20-cell-line cohort. Their definition was retained in the revised cohort; the fixed-composite predictive comparison is potentially optimistic. Training-only component selection is a different algorithm, not independent validation of the original signature.
- The molecular-only numerical reconstruction (MAE 31.46 kHz) and lineage-aware comparison (molecular-only MAE 37.61 kHz) use different tuning grids. Do not directly cross-compare their MAEs. The ordinal-coded regression is not a proportional-odds model.
- **M4b preprocessing:** selection of the four highest signed Spearman-correlated Hallmark features is training-only, repeated in inner and outer folds. The selected features use fixed external 24Q2 reference means and sample standard deviations (1,517 models) before equal-weight averaging; the resultant composite is standardized with training-fold mean and population standard deviation. The external fixed reference is not re-estimated from study labels or held-out outcomes. This is the actual frozen implementation. See 07_Reproducibility/METHOD_CLARIFICATION.md.
- Prior audit READMEs within subdirectories describe the historical stage at that time. This root README governs the current status; the full global max-T analysis is completed, the common-grid subset contains seven lines, and Figures 1–4 are finalized. Historical results are not the primary results.

No full upstream expression matrix, unrelated projects, duplicate preliminary Clean18 base package, or transient pre-freeze audit reports are included. See SHA256SUMS.txt for file integrity.
