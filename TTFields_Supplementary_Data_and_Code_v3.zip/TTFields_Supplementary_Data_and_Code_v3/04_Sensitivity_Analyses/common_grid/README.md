# Reviewer 2 Comment 2 — common-grid exploratory sensitivity audit

Created from uploaded WORK evidence inventory and the prior cohort17 composite_scores_17.csv.

## Inclusion
Seven lines, same author-verified grid 100,150,200,300,400 kHz; cell-count endpoint at 72 h; four source publications. Selected labels = 100 (1), 150 (3), 200 (3). This is a secondary common-grid restricted analysis, NOT a replacement primary cohort.

## Association
Composite vs selected-frequency Spearman rho = 0.848668425; ordinary two-sided nominal p=0.015744513; n=7. The fixed four-signature composite was originally selected post hoc; the p value is descriptive and does not account for selection or study clustering.

## Identifiability
All cell lines within each source publication have the SAME selected-frequency label. Thus there are zero studies with within-study label variation, and only one admissible within-study permutation assignment. A meaningful study-stratified exact permutation p value CANNOT be estimated for the association; fixed-effects identification is absent. Do not state p=1 as evidence of null; state test uninformative/not estimable.

## Robustness
Removing the Voloshin 2016 study leaves n=4 with rho=0.258198890, nominal p=0.741801110. See CSV for other leave-one-study-out results.

## Source-data constraint
The supplied 129-row frequency inventory contains no complete numerical full frequency-response curve for any cell line (values largely blank). The analysis uses the published SELECTED FREQUENCY LABELS, not actual response curves, and therefore does not test differences from adjacent frequencies or label uncertainty.

## Scientific conclusion
The requested common-grid restriction is feasible, and the pooled association remains descriptively positive. It does not establish a frequency association independent of source publication or post hoc composite selection.
