from pathlib import Path
from zipfile import ZipFile
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "rerun" / "figures"
OUT.mkdir(parents=True,exist_ok=True)
provenance=pd.read_csv(ROOT/"02_Primary_Cohort17/association_results/provenance_26_primary17_decisions.csv")
cohort=pd.read_csv(ROOT/"02_Primary_Cohort17/association_results/cohort_primary_17.csv")

excluded = provenance.loc[~provenance.Primary17Inclusion, "CellLine"]
categories = {
    "Identity concerns": {"U-118 MG", "NCI-H157"},
    "Frequency-label inconsistencies": {"A549", "NCI-H1299", "NCI-H1650", "NCI-H2052"},
    "Unresolved molecular mapping": {"U-87 MG", "U-343 MG"},
    "Molecular data unavailable": {"U-138 MG"},
}
assert set(excluded) == set().union(*categories.values())
assert sum(map(len,categories.values())) == len(excluded)
assert len(provenance)==26 and len(cohort)==17 and cohort.Study.nunique()==12
assert provenance.OriginalAnalysisInclusion.sum()==20
freq = [100,150,200,300]
counts=cohort.Frequency_kHz.value_counts().reindex(freq,fill_value=0)
assert counts.tolist()==[1,10,5,1]

ink="#182B3B"
blue="#2577A7"
gold="#E49408"
red="#C94F59"
purple="#8550A3"
grid="#E8EBEE"
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":15,
                    "text.color":ink,"axes.labelcolor":ink,
                    "xtick.color":ink,"ytick.color":ink,
                    "axes.edgecolor":"#333333","axes.linewidth":1.2,
                    "pdf.fonttype":42,"ps.fonttype":42,"figure.facecolor":"white"})
fig=plt.figure(figsize=(13.4,9.0))
axA=fig.add_axes([.045,.568,.91,.35])
axB=fig.add_axes([.045,.065,.52,.43])
axC=fig.add_axes([.63,.135,.325,.316])
for a in [axA,axB]:
    a.set_xlim(0,1);a.set_ylim(0,1);a.axis("off")

def heading(x,y,letter,label):
    fig.text(x,y,letter+"  "+label,fontsize=19,fontweight="bold",ha="left",va="top")
heading(.045,.958,"A","Study design and analytical workflow")
heading(.045,.528,"B","Primary analytical cohort construction")
heading(.605,.528,"C","Selected-frequency distribution")

def box(ax,x,y,w,h,fc,ec="#7095AD",lw=1.2):
    patch=FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.009,rounding_size=0.015",
                        transform=ax.transAxes,facecolor=fc,edgecolor=ec,lw=lw,
                        clip_on=False,zorder=2)
    ax.add_patch(patch)
    return patch
def txt(ax,x,y,s,**kw):
    ax.text(x,y,s,transform=ax.transAxes,**kw)
def arrow(ax,x1,y1,x2,y2,**kw):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),transform=ax.transAxes,
                  arrowstyle="-|>",mutation_scale=17,lw=1.7,color="#426C85",
                  shrinkA=0,shrinkB=0,clip_on=False,zorder=3,**kw))

steps=[
    ("1  Evidence curation","Published multi-frequency\nexperiments in human\ncancer cell lines\n\nTTFields and related\nintermediate-frequency\nfield exposures"),
    ("2  Cell-line mapping","Resolve cell-line names\nand duplicate records\n\nCross-reference Cellosaurus,\nCCLE and DepMap\n\nDocument uncertainties"),
    ("3  Molecular profiles","Expression: Public 26Q3\n(24Q2 sensitivity check)\nssGSEA: Public 24Q2\n\nLink by DepMap Model ID\nIndependently generated\nmolecular profiles"),
    ("4  Analyses","Targeted gene and\npathway associations\n\nPost hoc composite score\nStudy-structure sensitivity\n\nNested study-grouped\nprediction"),
]
w=.227; gap=.030
for i,(title,body) in enumerate(steps):
    x=i*(w+gap)
    box(axA,x,.095,w,.86,"#F1F6F9")
    # Header/body spacing is proportional and identical across steps.
    txt(axA,x+.015,.888,title,fontsize=15.3,fontweight="bold",ha="left",va="top")
    axA.plot([x+.014,x+w-.014],[.765,.765],transform=axA.transAxes,
             color="#B9CAD4",lw=1)
    txt(axA,x+.015,.710,body,fontsize=13.1,ha="left",va="top",linespacing=1.25)
    if i<3: arrow(axA,x+w+.009,.53,x+w+gap-.009,.53)

# B: cohort construction with explicit branch; the original cohort is a
# separate sensitivity set, not an additional branch of the 17-line cohort.
box(axB,.02,.83,.95,.125,"#EAF3F8")
txt(axB,.495,.892,"Curated human cancer cell lines  (n = 26)",
    fontsize=16,fontweight="bold",ha="center",va="center")
arrow(axB,.125,.827,.125,.365)
arrow(axB,.125,.65,.20,.65)
box(axB,.205,.43,.765,.335,"#FFF5E9","#CC9B60")
txt(axB,.587,.717,"Not included in primary analysis (n = 9)",
    fontsize=15.3,fontweight="bold",ha="center",va="center")
for i,(label,members) in enumerate(categories.items()):
    y=.65-i*.055
    txt(axB,.23,y,label,fontsize=13.6,ha="left",va="center")
    txt(axB,.935,y,str(len(members)),fontsize=14,fontweight="bold",ha="right",va="center")
box(axB,.02,.185,.95,.175,"#E6F2EC","#699879")
txt(axB,.495,.304,"Primary analytical cohort",fontsize=16.6,fontweight="bold",
    ha="center",va="center")
txt(axB,.495,.235,"n = 17  |  12 source publications",fontsize=15,ha="center",va="center")
box(axB,.02,.005,.95,.115,"#F1F4F6","#9AABB5")
txt(axB,.495,.062,"Original analytical cohort (n = 20) retained\nfor secondary sensitivity analyses.",
    fontsize=13.2,ha="center",va="center",linespacing=1.2)

axC.set_axisbelow(True)
axC.spines[["top","right"]].set_visible(False)
axC.yaxis.grid(True,color=grid,linewidth=0.9)
bars=axC.bar(range(4),counts.to_numpy(),width=.70,color=[blue,gold,red,purple],zorder=3)
axC.set(xlim=(-.55,3.55),ylim=(0,12.5),xticks=range(4),
        xticklabels=[str(x) for x in freq],
        yticks=range(0,13,2),xlabel="Selected-frequency label (kHz)",
        ylabel="Number of cell lines")
axC.tick_params(labelsize=15)
axC.set_title("Primary cohort (n = 17)",fontsize=15,fontweight="bold",pad=10)
for bar,n in zip(bars,counts):
    axC.text(bar.get_x()+bar.get_width()/2,n+.22,f"{n}\n({n/len(cohort):.1%})",
             ha="center",va="bottom",fontsize=14.4,fontweight="bold",linespacing=1.1)

fig.savefig(OUT/"Figure_1_Cohort17_Standardized.png",dpi=600,facecolor="white")
fig.savefig(OUT/"Figure_1_Cohort17_Standardized.pdf",facecolor="white")
fig.savefig(OUT/"Figure_1_Cohort17_Preview.png",dpi=130,facecolor="white")
print("Verified cohort: 26 curated, 9 excluded, 17 included, 12 source groups; frequency counts",counts.to_dict())
