from pathlib import Path
import json, zipfile
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import accuracy_score, balanced_accuracy_score
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
out=ROOT/"rerun"/"figures"
out.mkdir(parents=True,exist_ok=True)
data=ROOT/"03_Predictive_Modeling/molecular_only_stage2/model17"
reg=pd.read_csv(data/"regression_predictions.csv")
cls=pd.read_csv(data/"classification_predictions.csv")
recurrence=pd.read_csv(data/"regression_feature_recurrence.csv")
metrics=json.loads((data/"metrics.json").read_text())

assert len(reg) == 17 and reg.Study.nunique() == 12
assert len(cls) == 16 and cls.Study.nunique() == 12
assert set(reg.Frequency_kHz) == {100, 150, 200, 300}
assert set(cls.Frequency_kHz) == {100, 150, 200}
def regression_metrics(pred):
    err = reg[pred] - reg.Frequency_kHz
    return [np.abs(err).mean(), np.sqrt((err**2).mean())]

model_err = regression_metrics("prediction")
base_err = regression_metrics("baseline_prediction")
rho, p = spearmanr(reg.Frequency_kHz, reg.prediction)
def class_metrics(pred):
    return [100*accuracy_score(cls.Frequency_kHz, cls[pred]),
            100*balanced_accuracy_score(cls.Frequency_kHz, cls[pred])]

model_cls = class_metrics("prediction")
base_cls = class_metrics("baseline_prediction")
for values, key in [(model_err,"model"), (base_err,"baseline")]:
    expected = metrics["regression"]["metrics"][key]
    assert np.allclose(values, [expected["MAE_kHz"], expected["RMSE_kHz"]])
for values, key in [(model_cls,"model"), (base_cls,"baseline")]:
    expected = metrics["classification"]["metrics"][key]
    assert np.allclose(values, 100*np.array([expected["accuracy"],expected["balanced_accuracy"]]))
assert np.isclose(rho, metrics["regression"]["metrics"]["model"]["spearman_rho"])
assert np.isclose(p, metrics["regression"]["metrics"]["model"]["spearman_p_descriptive"])

ink="#182b3b"
blue="#2577A7"
gold="#E49408"
red="#C94F59"
purple="#8550A3"
grid="#E8EBEE"
plt.rcParams.update({
    "font.family":"DejaVu Sans","font.size":14,
    "axes.labelcolor":ink,"text.color":ink,"xtick.color":ink,"ytick.color":ink,
    "axes.edgecolor":"#333333","axes.linewidth":1.05,
    "xtick.major.width":1.0,"ytick.major.width":1.0,
    "xtick.major.size":4,"ytick.major.size":4,
    "pdf.fonttype":42,"ps.fonttype":42,"figure.facecolor":"white",
})
fig = plt.figure(figsize=(13.4,10.05))
a=fig.add_axes([.085,.59,.365,.35])
b=fig.add_axes([.615,.59,.365,.35])
c=fig.add_axes([.085,.085,.365,.35])
d=fig.add_axes([.615,.085,.365,.35])
assert a.get_position().x0 == c.get_position().x0
assert b.get_position().x0 == d.get_position().x0
for ax in [a,b,c,d]:
    ax.set_axisbelow(True)
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(axis="y",color=grid,linewidth=.7)
    ax.tick_params(labelsize=13)

def title(ax, letter, string):
    ax.set_title(f"{letter}  {string}",loc="left",fontweight="bold",fontsize=17,
                 pad=15,color=ink)

# A: exact observed and held-out predictions, no horizontal jitter.
title(a,"A","Nested regression (n = 17)")
lo,hi=70,325
a.plot([lo,hi],[lo,hi],ls="--",lw=1.3,color="#777777",zorder=1)
for f,col in [(100,blue),(150,gold),(200,red),(300,purple)]:
    g=reg.loc[reg.Frequency_kHz==f]
    a.scatter(g.Frequency_kHz,g.prediction,s=62,c=col,edgecolors="white",linewidths=.65,zorder=3)
a.set(xlim=(lo,hi),ylim=(lo,hi),xticks=[100,150,200,300],yticks=[100,150,200,250,300],
      xlabel="Observed selected-frequency\nlabel (kHz)",ylabel="Predicted selected frequency (kHz)")
a.grid(axis="x",color=grid,linewidth=.7)
a.text(.025,.975,f"Spearman ρ = {rho:.3f}; descriptive $p$ = {p:.3f}\n"
       f"MAE = {model_err[0]:.2f} kHz; RMSE = {model_err[1]:.2f} kHz",
       transform=a.transAxes,va="top",ha="left",fontsize=12.2,linespacing=1.4)

def grouped(ax, values, labels, legend, *, percent=False):
    x=np.arange(2); w=.32
    for j,(name,color) in enumerate(zip(legend,[blue,gold])):
        bars=ax.bar(x+(j-.5)*w,[vals[j] for vals in values],width=w*.94,color=color,
                    label=name,zorder=3)
        for rect in bars:
            val=rect.get_height()
            ax.text(rect.get_x()+rect.get_width()/2,val+(1.15 if percent else .9),
                    f"{val:.1f}%" if percent else f"{val:.2f}",ha="center",va="bottom",fontsize=13)
    ax.set_xticks(x,labels)
    ax.set_xlim(-.56,1.56)
    ax.legend(loc="upper left",frameon=False,fontsize=12,ncol=1 if percent else 2,
              handlelength=1.8,columnspacing=1.1)

title(b,"B","Regression versus baseline")
grouped(b,[model_err,base_err],["Hallmark ridge","Training-fold\nmedian baseline"],["MAE","RMSE"])
b.set(ylabel="Error (kHz)",ylim=(0,60),yticks=np.arange(0,61,10))

title(c,"C","Frequency classification (n = 16)")
grouped(c,[model_cls,base_cls],["Hallmark classifier","Training-fold\nmajority baseline"],
        ["Accuracy","Balanced accuracy"],percent=True)
c.set(ylabel="Performance (%)",ylim=(0,80),yticks=np.arange(0,81,10))

title(d,"D","Ridge feature recurrence")
names={
    "HALLMARK_FATTY_ACID_METABOLISM":"Fatty acid metabolism",
    "HALLMARK_SPERMATOGENESIS":"Spermatogenesis",
    "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION":"Epithelial–mesenchymal\ntransition",
    "HALLMARK_ANGIOGENESIS":"Angiogenesis",
    "HALLMARK_HEDGEHOG_SIGNALING":"Hedgehog signaling",
    "HALLMARK_APICAL_SURFACE":"Apical surface",
    "HALLMARK_KRAS_SIGNALING_DN":"KRAS signaling down",
    "HALLMARK_MYOGENESIS":"Myogenesis",
    "HALLMARK_WNT_BETA_CATENIN_SIGNALING":"WNT/β-catenin signaling",
}
top=recurrence.loc[recurrence.folds_selected>=10].copy()
assert len(top)==9 and set(top.feature)==set(names)
y=np.arange(len(top)); v=top.folds_selected.to_numpy()
d.grid(False,axis="y")
d.grid(True,axis="x",color=grid,linewidth=.7)
d.barh(y,v,height=.64,color=blue,zorder=3)
d.set_yticks(y,[names[n] for n in top.feature],fontsize=11)
d.invert_yaxis()
d.set(xlim=(0,13.7),xticks=[0,2,4,6,8,10,12],
      xlabel="Outer training folds\nselecting the feature")
for i,count in enumerate(v):
    d.text(count+.15,i,f"{count}/12",va="center",ha="left",fontsize=12)

fig.savefig(out/"Figure_4_Cohort17_Compact.png",dpi=600,facecolor="white")
fig.savefig(out/"Figure_4_Cohort17_Compact.pdf",facecolor="white")
fig.savefig(out/"Figure_4_Cohort17_Compact_Preview.png",dpi=120,facecolor="white")
print("Verified 17 regression predictions, 16 classification predictions, 12 folds, 9 top features.")
print("Regression:",model_err,base_err,"rho",rho,"p",p)
print("Classification:",model_cls,base_cls)
