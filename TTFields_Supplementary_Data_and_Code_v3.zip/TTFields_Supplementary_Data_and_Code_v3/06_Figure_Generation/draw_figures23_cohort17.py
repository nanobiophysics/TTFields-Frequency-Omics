from pathlib import Path
from zipfile import ZipFile
import pandas as pd
import numpy as np
from scipy.stats import spearmanr, pearsonr
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from textwrap import fill

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"rerun"/"figures"
OUT.mkdir(parents=True,exist_ok=True)
st1=ROOT/"02_Primary_Cohort17/association_results"
st2=ROOT/"03_Predictive_Modeling/molecular_only_stage2"
g=pd.read_csv(st1/"global_ssgsea_screen_17.csv")
h=pd.read_csv(st1/"hallmark_screen_17.csv")
c=pd.read_csv(st1/"composite_scores_17.csv")
d=pd.read_csv(st2/"model17/analysis_input_17.csv").set_index("ModelID")
ref=pd.read_csv(ROOT/"01_Inputs_and_Provenance/hallmark_reference_stats_1517.csv").set_index("Pathway")
loo=pd.read_csv(st2/"robustness/leave_one_study_out.csv")

keys=["HALLMARK_ANGIOGENESIS","HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION","HALLMARK_WNT_BETA_CATENIN_SIGNALING","HALLMARK_HEDGEHOG_SIGNALING"]
assert len(g)==31117 and len(h)==50 and len(c)==17 and c.Study.nunique()==12
c=c.sort_values(["Frequency_kHz","CellLine"])
z=(d.loc[c.ModelID,keys]-ref.loc[keys,"Mean"])/ref.loc[keys,"SD_ddof1"]
assert np.allclose(z.mean(axis=1),c.CompositeScore,atol=1e-6)
ink="#182B3B"; blue="#2577A7"; gold="#E49408"; red="#C94F59"; purple="#8550A3"; grid="#E8EBEE"
colors={100:blue,150:gold,200:red,300:purple}
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":14,"text.color":ink,"axes.labelcolor":ink,"xtick.color":ink,"ytick.color":ink,"axes.edgecolor":"#333333","axes.linewidth":1.1,"pdf.fonttype":42,"ps.fonttype":42,"figure.facecolor":"white"})
def style(ax,axis="y"):
    ax.spines[["top","right"]].set_visible(False)
    ax.set_axisbelow(True); ax.grid(axis=axis,color=grid,linewidth=.8)
    ax.tick_params(labelsize=13)
def title(ax,letter,s):
    ax.set_title(f"{letter}  {s}",loc="left",fontsize=18,fontweight="bold",pad=14)
def save(fig,n):
    for ext in ["png","pdf"]:
        fig.savefig(OUT/f"Figure_{n}_Cohort17_Compact.{ext}",dpi=600,facecolor="white")
    fig.savefig(OUT/f"Figure_{n}_Cohort17_Compact_Preview.png",dpi=120,facecolor="white")
    plt.close(fig)

# Figure 2: exact cutoff ties retained.
g=g.assign(absrho=g.rho.abs()).sort_values("absrho",ascending=False,kind="stable")
g=g[g.absrho>=g.absrho.iloc[11]-1e-12]
h=h.assign(absrho=h.rho.abs()).sort_values("absrho",ascending=False,kind="stable").head(8)
assert len(g)==13 and (h.q_BH<.05).sum()==1
fig=plt.figure(figsize=(13.4,11.8))
a=fig.add_axes([.285,.515,.155,.405]); b=fig.add_axes([.765,.515,.155,.405]); ax=fig.add_axes([.145,.155,.745,.17])
def bars(a,df,lab):
    yy=np.arange(len(df))
    a.barh(yy,df.rho,color=[gold if q<.05 else blue if r>=0 else red for r,q in zip(df.rho,df.q_BH)],height=.64,zorder=3)
    a.set_yticks(yy,lab); a.invert_yaxis(); style(a,"x"); a.tick_params(axis="y",labelsize=11.8)
    a.axvline(0,color="#888888",lw=.9)
    a.set_xlabel("Spearman ρ")
    a.set_xlim(-1,1)
    for i,(r,q) in enumerate(zip(df.rho,df.q_BH)):
        a.text(1.08,i,f"q = {q:.3f}",va="center",fontsize=10.8,clip_on=False)
    a.set_xticks([-1,0,1])
readable_global={
    "GO_WNT_SIGNALING_PATHWAY_INVOLVED_IN_HEART_DEVELOPMENT":"GO WNT signaling pathway\ninvolved in heart development",
    "PLASARI_TGFB1_SIGNALING_VIA_NFIC_1HR_UP":"Plasari TGFβ1 signaling\nvia NFIC 1 hr up",
    "NGUYEN_NOTCH1_TARGETS_UP":"Nguyen NOTCH1 targets up",
    "GO_FOREBRAIN_DORSAL_VENTRAL_PATTERN_FORMATION":"GO forebrain dorsal–ventral\npattern formation",
    "MODULE_497":"Module 497",
    "KEGG_ARRHYTHMOGENIC_RIGHT_VENTRICULAR_CARDIOMYOPATHY_ARVC":"KEGG arrhythmogenic right\nventricular cardiomyopathy (ARVC)",
    "GO_REGULATION_OF_AXON_GUIDANCE":"GO regulation of axon guidance",
    "GO_POSITIVE_REGULATION_OF_FILOPODIUM_ASSEMBLY":"GO positive regulation of\nfilopodium assembly",
    "PHESSE_TARGETS_OF_APC_AND_MBD2_UP":"Phesse targets of APC and MBD2 up",
}
labels=[readable_global.get(x,fill(x.replace("_"," "),width=31)) for x in g.Feature]
bars(a,g,labels)
a.tick_params(axis="y",labelsize=10.7)
fig.text(.035,.965,"A  Exploratory gene-set screen",fontsize=18,fontweight="bold",va="top")
hallmark_labels={"HALLMARK_WNT_BETA_CATENIN_SIGNALING":"WNT/β-catenin signaling","HALLMARK_KRAS_SIGNALING_DN":"KRAS signaling down"}
bars(b,h,[fill(hallmark_labels.get(x,x.removeprefix("HALLMARK_").replace("_"," ").capitalize()),24) for x in h.Feature])
fig.text(.55,.965,"B  Hallmark associations",fontsize=18,fontweight="bold",va="top")
fig.text(.29,.452,"Top 12 by |ρ| + cutoff tie (31,117 sets)\nNo global FDR q < 0.05",ha="center",va="top",fontsize=11.5)
fig.text(.775,.452,"Top 8 by |ρ| (50 Hallmark signatures)\nSpermatogenesis: FDR q < 0.05",ha="center",va="top",fontsize=11.5)
ax.imshow(z.T,aspect="auto",cmap="RdBu_r",norm=TwoSlopeNorm(vmin=-2,vcenter=0,vmax=2))
ax.set_xticks(np.arange(len(c)),c.CellLine,rotation=48,ha="right",fontsize=11.5)
ax.set_yticks(np.arange(4),["Angiogenesis","EMT","WNT/β-catenin","Hedgehog"],fontsize=12)
for y in [0.5,1.5,2.5]: ax.axhline(y,color="white",lw=.6)
for i in range(1,len(c)): 
    if c.Frequency_kHz.iloc[i]!=c.Frequency_kHz.iloc[i-1]: ax.axvline(i-.5,color=ink,lw=1.6)
ax.tick_params(length=0)
pos=ax.get_position()
fig.text(.035,.402,"C  Post hoc composite-component signatures",fontsize=18,fontweight="bold",va="top")
for f,grp in c.reset_index(drop=True).groupby("Frequency_kHz"):
    ax.text(np.mean(grp.index),1.10,str(f)+" kHz",transform=ax.get_xaxis_transform(),ha="center",va="bottom",fontsize=12,color=colors[f],fontweight="bold")
    ax.plot([grp.index.min()-.43,grp.index.max()+.43],[1.04,1.04],transform=ax.get_xaxis_transform(),color=colors[f],lw=1.5,clip_on=False)
cb=fig.colorbar(ax.images[0],cax=fig.add_axes([.902,.155,.013,.17]),ticks=[-2,-1,0,1,2])
cb.set_label("Reference-standardized\nssGSEA z-score",fontsize=11); cb.ax.tick_params(labelsize=11)
fig.text(.52,.033,"17 cell lines ordered by selected-frequency label",ha="center",fontsize=13)
save(fig,2)

# Figure 3: small deterministic horizontal offsets for point visibility.
fig=plt.figure(figsize=(13.4,10.05))
a=fig.add_axes([.085,.59,.365,.35]); b=fig.add_axes([.615,.59,.365,.35])
cc=fig.add_axes([.085,.085,.365,.35]); e=fig.add_axes([.615,.085,.365,.35])
assert b.get_position().x0==e.get_position().x0
for ax in [a,b,cc,e]: style(ax)
rho,p=spearmanr(c.Frequency_kHz,c.CompositeScore)
def dots(ax,df,col):
    for f,grp in df.groupby("Frequency_kHz"):
        grp=grp.sort_values(col)
        offsets=np.zeros(len(grp))
        vals=grp[col].to_numpy()
        start=0
        for end in range(1,len(vals)+1):
            if end==len(vals) or vals[end]-vals[end-1]>.075:
                if end-start>1: offsets[start:end]=np.linspace(-3.6,3.6,end-start)
                start=end
        ax.scatter(grp.Frequency_kHz+offsets,grp[col],s=66,c=colors[f],edgecolors="white",linewidths=.65,zorder=4)
    ax.set(xlim=(80,320),xticks=[100,150,200,300],ylim=(-.68,1.60),yticks=np.arange(-.5,1.51,.25),xlabel="Selected-frequency label (kHz)",ylabel="Composite score")
dots(a,c,"CompositeScore")
title(a,"A","Cell-line association (n = 17)")
pr,pp=pearsonr(c.Frequency_kHz,c.CompositeScore)
a.text(.025,.97,f"Spearman ρ = {rho:.3f}; nominal p = {p:.5f}\nPearson r = {pr:.3f}; nominal p = {pp:.5f}",transform=a.transAxes,va="top",fontsize=12)
title(b,"B","Frequency-group summaries")
for i,(f,grp) in enumerate(c.groupby("Frequency_kHz")):
    vals=np.sort(grp.CompositeScore.to_numpy())
    offset=np.linspace(-.18,.18,len(vals)) if len(vals)>1 else [0]
    b.scatter(i+np.array(offset),vals,s=77,color=colors[f],edgecolor="white",linewidth=.65,zorder=3)
    if len(vals)>=3: b.hlines(vals.mean(),i-.27,i+.27,linewidth=2.5,color=colors[f],zorder=4)
    b.text(i,1.50,f"n = {len(vals)}"+(f"\nMean {vals.mean():.3f}" if len(vals)>=3 else ""),ha="center",va="top",fontsize=11)
b.set(xticks=range(4),xticklabels=[str(f) for f in sorted(colors)],xlim=(-.45,3.45),ylim=(-.68,1.60),yticks=np.arange(-.5,1.51,.25),xlabel="Selected-frequency label (kHz)",ylabel="Composite score")
agg=c.groupby(["Study","Frequency_kHz"],as_index=False).CompositeScore.mean()
assert len(agg)==13
r,p2=spearmanr(agg.Frequency_kHz,agg.CompositeScore)
dots(cc,agg,"CompositeScore")
title(cc,"C","Study × frequency means (n = 13)")
cc.set_ylabel("Mean composite score")
cc.text(.025,.97,f"Spearman ρ = {r:.3f}; nominal p = {p2:.5f}",transform=cc.transAxes,va="top",fontsize=12)
title(e,"D","Leave-one-study-out (12 groups)")
names=c.drop_duplicates("Study").set_index("Study").SourcePublication
loo=loo.sort_values("rho",ascending=False)
yy=np.arange(len(loo))
e.scatter(loo.rho,yy,color=blue,s=58,edgecolors="white",linewidths=.5,zorder=3)
e.axvline(rho,color="#687481",linestyle="--",linewidth=1.5,label=f"Full cohort ρ = {rho:.3f}")
e.set_yticks(yy,[names[s].replace(" et al.","") for s in loo.removed_study],fontsize=11.5)
e.invert_yaxis(); e.grid(True,axis="y",color=grid)
e.set(xlim=(.55,.85),xticks=np.arange(.55,.851,.05),xlabel="Spearman ρ after study omission")
e.legend(loc="lower right",frameon=False,fontsize=11)
save(fig,3)
print("Verified heatmap and composite, Figure 3:",rho,p,r,p2,"LOSO:",loo.rho.min(),loo.rho.max())
