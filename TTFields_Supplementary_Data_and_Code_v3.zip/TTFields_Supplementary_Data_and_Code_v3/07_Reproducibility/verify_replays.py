"""Run after the six analysis scripts; compare replayed outputs to frozen records."""
from pathlib import Path
import numpy as np
import pandas as pd
import json
P=Path(__file__).resolve().parents[1]
R=P/"rerun"
M=P/"03_Predictive_Modeling"
A=P/"02_Primary_Cohort17"
checks=[]
def compare(name,new,old,keys,cols=None):
    a=pd.read_csv(new).set_index(keys).sort_index()
    b=pd.read_csv(old).set_index(keys).sort_index()
    assert a.index.equals(b.index), name
    if cols is None: cols=list(b.columns.intersection(a.columns))
    for c in cols:
        if pd.api.types.is_numeric_dtype(b[c]):
            np.testing.assert_allclose(a[c],b[c],atol=1e-8,rtol=1e-8,equal_nan=True,err_msg=name+"/"+c)
        else: assert a[c].fillna("").equals(b[c].fillna("")), name+"/"+c
    checks.append((name,len(a),"PASS"))
for task in ["regression","classification"]:
    compare(task+" held-out predictions",R/"molecular_only"/f"{task}_predictions.csv",M/"molecular_only_stage2/model17"/f"{task}_predictions.csv",["ModelID"],["Frequency_kHz","Study","prediction","baseline_prediction"])
    compare(task+" feature recurrence",R/"molecular_only"/f"{task}_feature_recurrence.csv",M/"molecular_only_stage2/model17"/f"{task}_feature_recurrence.csv",["feature"])
compare("lineage comparison",R/"lineage/lineage_model_comparison_nested_LOSO_17.csv",M/"lineage_comparison/PRIMARY_comparable_nested_LOSO_models_17.csv",["representation","model"],["n","MAE_kHz","RMSE_kHz","baseline_MAE_kHz","baseline_RMSE_kHz"])
compare("lineage fold tuning",R/"lineage/lineage_model_outer_fold_tuning_17.csv",M/"lineage_comparison/primary_outer_fold_tuning.csv",["representation","model","held_out_study"])
compare("lineage held-out predictions",R/"lineage/held_out_predictions_17.csv",M/"lineage_comparison/held_out_predictions_17.csv",["representation","model","ModelID"],["Study","observed","prediction","baseline_prediction"])
compare("ordinal sensitivity",R/"ordinal/ordinal_model_comparison_17.csv",M/"ordinal_and_replay/ordinal_model_comparison_17.csv",["model"])
compare("ordinal held-out predictions",R/"ordinal/ordinal_model_outer_predictions_17.csv",M/"ordinal_and_replay/ordinal_model_outer_predictions_17.csv",["model","ModelID"],["CellLine","Study","observed_kHz","predicted_kHz","baseline_kHz"])
compare("global exact max-T",R/"study_lineage/global_31117_exact_maxT_17.csv",A/"study_lineage_tests/global_31117_exact_maxT_17.csv",["GeneSet"])
compare("exact Hallmark fixed and reselected composites",R/"study_lineage/exact_permutation_selection_17.csv",A/"study_lineage_tests/exact_permutation_selection_17.csv",["observed"],["selected_top4","selected_rho","fixed4_rho","max_abs_hallmark","spermatogenesis_rho"])
new=json.loads((R/"associations/cluster_bootstrap_replay.json").read_text())
old=json.loads((M/"molecular_only_stage2/robustness/bootstrap_summary.json").read_text())
assert new["seed"]==old["bootstrap_seed"] and new["valid"]==old["valid_draws"]
np.testing.assert_allclose(new["percentile_95_ci"],old["percentile_95_ci"],atol=1e-10)
checks.append(("cluster bootstrap",new["valid"],"PASS"))
pd.DataFrame(checks,columns=["check","records","status"]).to_csv(R/"replay_validation.csv",index=False)
print(pd.DataFrame(checks,columns=["check","records","status"]).to_string(index=False))
