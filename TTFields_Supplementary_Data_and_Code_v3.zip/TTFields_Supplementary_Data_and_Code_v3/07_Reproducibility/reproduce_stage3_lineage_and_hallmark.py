from pathlib import Path
P=Path(__file__).resolve().parents[1]

import pandas as pd, numpy as np, json
from scipy.stats import rankdata,spearmanr,pearsonr
from itertools import permutations,product
O=P/'rerun'/'study_lineage';O.mkdir(parents=True,exist_ok=True)
A=pd.read_csv(P/'02_Primary_Cohort17/association_results/cohort_primary_17.csv')
S=pd.read_csv(P/'02_Primary_Cohort17/association_results/composite_scores_17.csv')
A=A.merge(S[['ModelID','CompositeScore']],on='ModelID',validate='one_to_one')

# The full 31,117-feature candidate matrix including RBE is supplied separately.
H=pd.read_csv(P/'03_Predictive_Modeling/molecular_only_stage2/model17/analysis_input_17.csv')
H=H.set_index('ModelID').loc[A.ModelID]
assert len(H)==17
cs=A.CellLine.to_list()
lineages={'MDA-MB-231':'Breast','A2780':'Ovary','OVCAR-3':'Ovary','Caov-3':'Ovary','HCC4006':'Lung','MSTO-211H':'Mesothelioma','KNS42':'CNS','DAOY':'CNS','AGS':'Stomach','KATO III':'Stomach','HepG2':'Liver_hepatoblastoma','AsPC-1':'Pancreas','HCC827':'Lung','NCI-H520':'Lung','GaMG':'CNS','MES-SA':'Uterus_sarcoma','RBE':'Biliary'}
A['Lineage']=A.CellLine.map(lineages)
A['CNS']=A.Lineage.eq('CNS').astype(int)
assert A.Lineage.notna().all()
A.to_csv(O/'cohort17_with_lineages.csv',index=False)
y=A.Frequency_kHz.to_numpy(float);c=A.CompositeScore.to_numpy(float)
def residualcorr(c,y,cat):
 Z=pd.get_dummies(cat,drop_first=False).to_numpy(float)
 # full indicator matrix spans intercept
 yc=rankdata(y);cc=rankdata(c)
 yr=yc-Z@np.linalg.lstsq(Z,yc,rcond=None)[0]
 cr=cc-Z@np.linalg.lstsq(Z,cc,rcond=None)[0]
 return {'r_partial_rank_residual':float(pearsonr(yr,cr).statistic),'n_groups':int(Z.shape[1]),'residual_x_norm':float(np.linalg.norm(yr)), 'residual_score_norm':float(np.linalg.norm(cr))}
res={'composite':{'rho':float(spearmanr(y,c).statistic),'p_nominal':float(spearmanr(y,c).pvalue)},'lineage_binary':residualcorr(c,y,A.CNS),'lineage_detailed':residualcorr(c,y,A.Lineage)}
# within study slope: composite score per 100kHz
A['frequency_centered']=A.Frequency_kHz-A.groupby('Study').Frequency_kHz.transform('mean')
A['composite_centered']=A.CompositeScore-A.groupby('Study').CompositeScore.transform('mean')
xi=A.frequency_centered.to_numpy(float)/100;yi=A.composite_centered.to_numpy(float)
res['study_fixed_effects']={'slope_score_per_100kHz':float(np.dot(xi,yi)/np.dot(xi,xi)), 'n_studies_with_within_study_frequency_variation':int((A.groupby('Study').Frequency_kHz.nunique()>1).sum()), 'contributing_study':A.groupby('Study').Frequency_kHz.nunique().loc[lambda s:s>1].index.tolist()}
# exact two allocations (other groups fixed); rank-based association and selection-aware test
hallcols=[col for col in H if col.startswith('HALLMARK_')]
assert len(hallcols)==50
ref=pd.read_csv(P/'01_Inputs_and_Provenance/hallmark_reference_stats_1517.csv').set_index('Pathway')
Z=(H[hallcols].to_numpy(float)-ref.loc[hallcols,'Mean'].to_numpy()[None,:])/ref.loc[hallcols,'SD_ddof1'].to_numpy()[None,:]
rr=rankdata(H[hallcols].to_numpy(float),axis=0);rr=rr-rr.mean(axis=0);rr=rr/np.linalg.norm(rr,axis=0)
obs_y=y.copy()
group_ix=[part.index.to_numpy() for _,part in A.groupby('Study',sort=True)]
yset=[]
for pp in product(*[sorted(set(permutations(y[ix].tolist()))) for ix in group_ix]):
 z=y.copy()
 for ix,vals in zip(group_ix,pp):z[ix]=vals
 if not any(np.array_equal(z,old) for old in yset):yset.append(z)
assert len(yset)==2
rows=[]
for yy in yset:
 r=rankdata(yy);r-=r.mean();r/=np.linalg.norm(r)
 vals=r@rr
 selected=np.argsort(-vals,kind='stable')[:4]
 sel_score=Z[:,selected].mean(axis=1)
 fixed_obs_top=['HALLMARK_ANGIOGENESIS','HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION','HALLMARK_WNT_BETA_CATENIN_SIGNALING','HALLMARK_HEDGEHOG_SIGNALING']
 fixed_score=Z[:,[hallcols.index(j) for j in fixed_obs_top]].mean(axis=1)
 rows.append({'observed':bool(np.array_equal(yy,y)), 'selected_top4':';'.join(np.asarray(hallcols)[selected]),'selected_rho':float(spearmanr(yy,sel_score).statistic),'fixed4_rho':float(spearmanr(yy,fixed_score).statistic),'max_abs_hallmark':float(np.abs(vals).max()),'spermatogenesis_rho':float(vals[hallcols.index('HALLMARK_SPERMATOGENESIS')]),'max_abs_global':None})
R=pd.DataFrame(rows);R.to_csv(O/'exact_permutation_selection_17.csv',index=False)
ob=R.loc[R.observed].iloc[0]
res['study_exact_hallmark']={'assignments':2,'reselected_top4_observed':ob.selected_top4,'reselected_rho_observed':float(ob.selected_rho),'reselected_p_two_sided':float((R.selected_rho.abs()>=abs(ob.selected_rho)-1e-12).mean()),'fixed4_p_two_sided':float((R.fixed4_rho.abs()>=abs(ob.fixed4_rho)-1e-12).mean()),'spermatogenesis_exact_p':float((R.spermatogenesis_rho.abs()>=abs(ob.spermatogenesis_rho)-1e-12).mean()),'spermatogenesis_maxT_fwer_p':float((R.max_abs_hallmark>=abs(ob.spermatogenesis_rho)-1e-12).mean()),'global_maxT_status':'Separate full global max-T script and frozen output are included.'}
# Full global max-T is evaluated separately.
with open(O/'summary_stage3.json','w') as f:json.dump(res,f,indent=2)
print(json.dumps(res,indent=2))
