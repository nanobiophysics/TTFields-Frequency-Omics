import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,pandas as pd,json
from pathlib import Path
P=Path(__file__).resolve().parents[1]

from scipy.stats import spearmanr,rankdata
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
O=P/'rerun'/'lineage'
O.mkdir(parents=True, exist_ok=True)
a=pd.read_csv(P/'02_Primary_Cohort17/study_lineage_tests/cohort17_with_lineages.csv')
h=pd.read_csv(P/'03_Predictive_Modeling/molecular_only_stage2/model17/analysis_input_17.csv').set_index('ModelID').loc[a.ModelID]
features=sorted([c for c in h if c.startswith('HALLMARK_')]);x=h[features].to_numpy(float)
y=a.Frequency_kHz.to_numpy(float);g=a.Study.to_numpy();com=a.CompositeScore.to_numpy(float)
ref=pd.read_csv(P/'01_Inputs_and_Provenance/hallmark_reference_stats_1517.csv').set_index('Pathway');std=(h[features].to_numpy(float)-ref.loc[features,'Mean'].to_numpy())/ref.loc[features,'SD_ddof1'].to_numpy()
# 10-category lineage: training-defined, unseen categories = zeros
ks=[3,5,10]; alphas=[.1,1,10,100]
def predict(tr,va,model,lineage,k,alpha):
    yy=y[tr];X=x[tr];V=x[va]
    pieces=[];outs=[]
    if model!='molecular_only':
      col=a[lineage] if lineage=='Lineage' else a.CNS.astype(str)
      cats=sorted(col.iloc[tr].unique())
      # retain categories as unscaled one-hot, no unknown indicators in test
      ltr=np.column_stack([(col.iloc[tr].to_numpy()==v).astype(float) for v in cats]);lva=np.column_stack([(col.iloc[va].to_numpy()==v).astype(float) for v in cats]);pieces.append(ltr);outs.append(lva)
    if model in ['molecular_only','lineage_plus_hallmark']:
      ranks=rankdata(X,axis=0); ranks-=ranks.mean(axis=0); ry=rankdata(yy);ry-=ry.mean();den=np.linalg.norm(ry)*np.linalg.norm(ranks,axis=0); z=np.divide(ry@ranks,den,out=np.zeros(X.shape[1]),where=den>0)
      ix=np.argsort(-np.abs(z),kind='stable')[:k]
      scale=StandardScaler().fit(X[:,ix]);pieces.append(scale.transform(X[:,ix]));outs.append(scale.transform(V[:,ix]))
    if model=='lineage_plus_fixed_composite':
      sc=StandardScaler().fit(com[tr,None]);pieces.append(sc.transform(com[tr,None]));outs.append(sc.transform(com[va,None]))
    if model=='lineage_plus_training_selected':
      ranks=rankdata(X,axis=0); ranks-=ranks.mean(axis=0);ry=rankdata(yy);ry-=ry.mean();den=np.linalg.norm(ry)*np.linalg.norm(ranks,axis=0); corr=np.divide(ry@ranks,den,out=np.zeros(X.shape[1]),where=den>0)
      idx=np.argsort(-corr,kind='stable')[:4]
      ctrain=std[tr][:,idx].mean(axis=1)[:,None];cval=std[va][:,idx].mean(axis=1)[:,None]
      scaler=StandardScaler().fit(ctrain);pieces.append(scaler.transform(ctrain));outs.append(scaler.transform(cval))
    xx=np.column_stack(pieces);vv=np.column_stack(outs)
    return Ridge(alpha=alpha).fit(xx,yy).predict(vv)
models=['lineage_only','molecular_only','lineage_plus_hallmark','lineage_plus_fixed_composite','lineage_plus_training_selected']
all_rows=[];folds=[];oof=[]
for lineage in ['CNS','Lineage']:
 for m in models:
  if m=='molecular_only' and lineage=='Lineage':continue
  pred=np.zeros(len(a));baseline=np.zeros(len(a))
  for study in sorted(set(g)):
   train=np.flatnonzero(g!=study);test=np.flatnonzero(g==study)
   params=[]
   for k in ([0] if m not in ['molecular_only','lineage_plus_hallmark'] else ks):
    for alpha in alphas:
     ip=np.zeros(len(train))
     for isub in sorted(set(g[train])):
      inner_tr=train[g[train]!=isub];inner_va=train[g[train]==isub]
      ip[g[train]==isub]=predict(inner_tr,inner_va,m,lineage,k,alpha)
     loss=float(np.mean(np.abs(y[train]-ip)));params.append((loss,k,alpha))
   loss,k,alpha=min(params,key=lambda z:(round(z[0],10),z[1],-z[2]))
   pred[test]=predict(train,test,m,lineage,k,alpha);baseline[test]=np.median(y[train]);folds.append({'representation':lineage,'model':m,'held_out_study':study,'best_k':k,'alpha':alpha,'inner_MAE':loss,'test_n':len(test)})
  mae=float(np.mean(abs(pred-y)));rmse=float(np.sqrt(np.mean((pred-y)**2)))
  all_rows.append({'representation':lineage,'model':m,'n':len(y),'MAE_kHz':mae,'RMSE_kHz':rmse,'baseline_MAE_kHz':float(np.mean(abs(baseline-y))),'baseline_RMSE_kHz':float(np.sqrt(np.mean((baseline-y)**2)))})
  print(lineage,m,'MAE',round(mae,3),flush=True)
  for idx in range(len(y)): oof.append({'representation':lineage,'model':m,'ModelID':a.ModelID.iloc[idx],'Study':g[idx],'observed':y[idx],'prediction':pred[idx],'baseline_prediction':baseline[idx]})
pd.DataFrame(all_rows).to_csv(O/'lineage_model_comparison_nested_LOSO_17.csv',index=False);pd.DataFrame(folds).to_csv(O/'lineage_model_outer_fold_tuning_17.csv',index=False)
(O/'lineage_model_methods.txt').write_text('Nested leave-one-study-out (outer and inner), ridge regression alpha grid .1,1,10,100; training-only absolute Spearman feature ranking k 3,5,10 for molecular-only and lineage+Hallmark. Models M1 lineage-only, M2 molecular-only, M3 lineage+Hallmark, M4 lineage+fixed post hoc composite (selection leakage; descriptive only), M5 lineage+top4 positively correlated Hallmarks reselected in each training split and z-standardized with fixed 24Q2 reference stats. Separate binary CNS and ten-category lineage classification. One-hot categories not observed in training are all-zero in heldout. Internal/retrospective only; does not establish independent predictive utility. Comparison algorithm is a new reconstruction, not claimed identical to previously reported Supplementary Table S5 methods.\n')

pd.DataFrame(oof).to_csv(O/'held_out_predictions_17.csv',index=False)
