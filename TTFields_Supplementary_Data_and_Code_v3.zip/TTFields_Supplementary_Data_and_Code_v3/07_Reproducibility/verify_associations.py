"""Verify frozen primary association results from supplied molecular inputs."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr, pearsonr, t

P=Path(__file__).resolve().parents[1]
I=P/"01_Inputs_and_Provenance"
A=P/"02_Primary_Cohort17/association_results"
M=P/"03_Predictive_Modeling/molecular_only_stage2"
R=P/"rerun"/"associations"
R.mkdir(parents=True,exist_ok=True)
co=pd.read_csv(A/"cohort_primary_17.csv")
assert len(co)==17 and co.ModelID.is_unique and co.Study.nunique()==12
y=co.Frequency_kHz.to_numpy(float)
assert co.Frequency_kHz.value_counts().sort_index().tolist()==[1,10,5,1]
def bh(p):
    idx=np.argsort(p); q=np.empty_like(p); q[idx]=np.minimum.accumulate((p[idx]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1];return q.clip(0,1)
def screen(x,filename):
    rx=rankdata(x.to_numpy(float),axis=0);ry=rankdata(y)
    rx-=rx.mean(0);ry-=ry.mean()
    rho=ry@rx/(np.linalg.norm(ry)*np.linalg.norm(rx,axis=0))
    p=2*t.sf(np.abs(rho)*np.sqrt((len(y)-2)/np.maximum(1-rho**2,1e-30)),len(y)-2)
    d=pd.DataFrame({"Feature":x.columns,"rho":rho,"p_nominal":p,"q_BH":bh(p)}).set_index("Feature")
    check=pd.read_csv(A/filename).set_index("Feature")
    np.testing.assert_allclose(d.loc[check.index,check.columns],check,rtol=1e-7,atol=1e-9)
    d.reset_index().to_csv(R/filename,index=False)
    print(filename,"verified",len(d))
x=pd.read_csv(I/"candidate_rows_all_gene_sets.csv").set_index("ModelID").loc[co.ModelID]
assert x.shape==(17,31117)
screen(x,"global_ssgsea_screen_17.csv")
h=x.filter(regex="^HALLMARK_")
assert h.shape==(17,50)
screen(h,"hallmark_screen_17.csv")
raw_model=pd.read_csv(M/"model17/analysis_input_17.csv").set_index("ModelID").loc[co.ModelID,h.columns]
np.testing.assert_allclose(h,raw_model,rtol=0,atol=1e-10)
ref=pd.read_csv(I/"hallmark_reference_stats_1517.csv").set_index("Pathway")
features=["HALLMARK_ANGIOGENESIS","HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION","HALLMARK_WNT_BETA_CATENIN_SIGNALING","HALLMARK_HEDGEHOG_SIGNALING"]
z=(h[features]-ref.loc[features,"Mean"])/ref.loc[features,"SD_ddof1"]
cs=z.mean(axis=1)
known=pd.read_csv(A/"composite_scores_17.csv").set_index("ModelID").loc[co.ModelID,"CompositeScore"]
np.testing.assert_allclose(cs,known,rtol=0,atol=1e-9)
co["CompositeScore"]=cs.to_numpy()
mods=pd.read_csv(I/"module_definitions_crossrelease.csv")
for release,num in [("24Q2",1517),("26Q3",2130)]:
    exp=pd.read_csv(I/f"expression_reference_{release}_{num}_by_26.csv").set_index("ModelID")
    assert exp.shape==(num,26)
    zx=((exp-exp.mean())/exp.std(ddof=1)).loc[co.ModelID]
    screen(zx,f"genes_26_{release}_17.csv")
    score=pd.DataFrame({m:zx[genes.split(";")].mean(axis=1) for m,genes in zip(mods.Module,mods.MemberGenes)})
    screen(score,f"modules_7_{release}_17.csv")
print("Composite Spearman/Pearson",spearmanr(y,cs),pearsonr(y,cs))
agg=co.groupby(["Study","Frequency_kHz"],as_index=False).CompositeScore.mean()
assert len(agg)==13
print("13 study x frequency strata",spearmanr(agg.Frequency_kHz,agg.CompositeScore))
for file,col,key in [("leave_one_study_out.csv","Study","removed_study"),("leave_one_cell_out.csv","CellLine","removed")]:
    for row in pd.read_csv(M/"robustness"/file).to_dict("records"):
        keep=co[co[col]!=row[key]]
        np.testing.assert_allclose(spearmanr(keep.Frequency_kHz,keep.CompositeScore).statistic,row["rho"],atol=1e-10)
    print(file,"verified")
grid=pd.read_csv(P/"04_Sensitivity_Analyses/common_grid/common_grid7_cohort_and_composite.csv")
assert len(grid)==7 and grid.Study.nunique()==4
np.testing.assert_allclose(grid.CompositeScore,co.set_index("ModelID").loc[grid.ModelID,"CompositeScore"])
print("Identical grid",spearmanr(grid.Frequency_kHz,grid.CompositeScore))
sub=grid[grid.Study!="Voloshin_2016"]
print("Identical grid excluding Voloshin",spearmanr(sub.Frequency_kHz,sub.CompositeScore))
conv=pd.read_csv(I/"conventional_features_sources.csv").set_index("ModelID").reindex(co.ModelID)
for column in ["DoublingTime_h","CellDiameter_um"]:
    valid=conv[column].notna()
    print(column,valid.sum(),spearmanr(y[valid],conv.loc[valid,column]))
print("All frozen association result tables and leave-one-out correlations verified.")
# Source-study bootstrap preserves all observations belonging to each sampled study.
import json
groups=[grp.index.to_numpy() for _,grp in co.groupby("Study",sort=True)]
rng=np.random.default_rng(20261121)
vals=[]
for draw in rng.integers(0,len(groups),size=(10000,len(groups))):
    ix=np.concatenate([groups[i] for i in draw])
    if np.unique(y[ix]).size<2 or np.unique(cs.to_numpy()[ix]).size<2:
        continue
    vals.append(spearmanr(y[ix],cs.to_numpy()[ix]).statistic)
ci=np.percentile(vals,[2.5,97.5])
report={"seed":20261121,"draws":10000,"valid":len(vals),"percentile_95_ci":ci.tolist()}
(R/"cluster_bootstrap_replay.json").write_text(json.dumps(report,indent=2))
print("Bootstrap replay",report)
