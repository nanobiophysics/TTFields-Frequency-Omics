"""Ordinal-coded ridge sensitivity: nested LOSO, training-only feature selection and scaling.
Ordinal class targets 0,1,2,3; round and clip to 0..3, mapped to 100,150,200,300 kHz.
This is ordinal-coded regression, not a cumulative-link/proportional odds model.
"""
import os;os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,pandas as pd,json
from pathlib import Path
P=Path(__file__).resolve().parents[1]

from scipy.stats import rankdata
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import balanced_accuracy_score
ROOT=P/'rerun'/'ordinal'
ROOT.mkdir(parents=True, exist_ok=True)
co=pd.read_csv(P/'02_Primary_Cohort17/study_lineage_tests/cohort17_with_lineages.csv')
dat=pd.read_csv(P/'03_Predictive_Modeling/molecular_only_stage2/model17/analysis_input_17.csv').set_index('ModelID').loc[co.ModelID]
fs=sorted([v for v in dat if v.startswith('HALLMARK_')]); X=dat[fs].to_numpy(float)
y=co.Frequency_kHz.to_numpy(float); cats=np.array([100,150,200,300]); t=np.searchsorted(cats,y).astype(float)
g=co.Study.to_numpy(); line=co.Lineage.to_numpy(); cns=co.CNS.to_numpy()
ref=pd.read_csv(P/'01_Inputs_and_Provenance/hallmark_reference_stats_1517.csv').set_index('Pathway')
Z=(X-ref.loc[fs,'Mean'].to_numpy())/ref.loc[fs,'SD_ddof1'].to_numpy()
assert len(y)==17 and len(fs)==50 and len(set(g))==12
K=[2,5,10]; A=[.1,1,10,100]
def corr_rank(x,t):
    rr=rankdata(x,axis=0);ry=rankdata(t)
    rr-=rr.mean(axis=0);ry-=ry.mean()
    den=np.linalg.norm(rr,axis=0)*np.linalg.norm(ry)
    return np.divide(ry@rr,den,out=np.zeros(x.shape[1]),where=den>0)
def features(tr,va,model,k,alpha):
    blocks=[];test=[]
    if 'lineage' in model:
        z=line if 'ten' in model else cns
        u=sorted(set(z[tr]));blocks.append(np.column_stack([(z[tr]==v).astype(float) for v in u]));test.append(np.column_stack([(z[va]==v).astype(float) for v in u]))
    if model in ('molecular','lineage_binary_plus_molecular','lineage_ten_plus_molecular'):
        selected=np.argsort(-abs(corr_rank(X[tr],t[tr])),kind='stable')[:k]
        scale=StandardScaler().fit(X[tr][:,selected]);blocks.append(scale.transform(X[tr][:,selected]));test.append(scale.transform(X[va][:,selected]))
    if 'train_selected_composite' in model:
        selected=np.argsort(-corr_rank(X[tr],t[tr]),kind='stable')[:4]
        tr_comp=Z[tr][:,selected].mean(axis=1)[:,None];va_comp=Z[va][:,selected].mean(axis=1)[:,None]
        scale=StandardScaler().fit(tr_comp);blocks.append(scale.transform(tr_comp));test.append(scale.transform(va_comp))
    ztrain=np.column_stack(blocks);ztest=np.column_stack(test)
    pred=Ridge(alpha=alpha).fit(ztrain,t[tr]).predict(ztest)
    return np.rint(pred).clip(0,3).astype(int)
models=['molecular','lineage_binary','lineage_ten','lineage_binary_plus_molecular','lineage_ten_plus_molecular','lineage_binary_plus_train_selected_composite','lineage_ten_plus_train_selected_composite']
rows=[];oof=[];tuning=[]
for model in models:
    preds=np.full(len(t),-1,int);base=np.full(len(t),-1,int)
    for study in sorted(set(g)):
        tr=np.flatnonzero(g!=study);va=np.flatnonzero(g==study)
        choices=[]
        for k in (K if 'molecular' in model else [0]):
            for alpha in A:
                inn=np.full(len(tr),-1,int)
                for inner in sorted(set(g[tr])):
                    itr=tr[g[tr]!=inner];iva=tr[g[tr]==inner];inn[g[tr]==inner]=features(itr,iva,model,k,alpha)
                loss=np.mean(abs(cats[inn]-y[tr]));choices.append((loss,k,alpha))
        score,k,alpha=min(choices,key=lambda v:(round(v[0],10),v[1],-v[2]))
        preds[va]=features(tr,va,model,k,alpha)
        base[va]=int(np.searchsorted(cats,np.median(y[tr])))
        tuning.append({'model':model,'held_out_study':study,'selected_k':k,'alpha':alpha,'inner_mae_kHz':score})
    predicted=cats[preds];baseline=cats[base]
    rows.append({'model':model,'n':len(y),'MAE_kHz':float(np.mean(abs(predicted-y))),'RMSE_kHz':float(np.sqrt(np.mean((predicted-y)**2))),'exact_accuracy':float(np.mean(predicted==y)),'balanced_accuracy':float(balanced_accuracy_score(y,predicted)),'baseline_MAE_kHz':float(np.mean(abs(baseline-y))),'baseline_balanced_accuracy':float(balanced_accuracy_score(y,baseline))})
    for i in range(len(y)):oof.append({'model':model,'ModelID':co.ModelID.iloc[i],'CellLine':co.CellLine.iloc[i],'Study':g[i],'observed_kHz':y[i],'predicted_kHz':predicted[i],'baseline_kHz':baseline[i]})
    print(rows[-1],flush=True)
pd.DataFrame(rows).to_csv(ROOT/'ordinal_model_comparison_17.csv',index=False)
pd.DataFrame(oof).to_csv(ROOT/'ordinal_model_outer_predictions_17.csv',index=False)
pd.DataFrame(tuning).to_csv(ROOT/'ordinal_model_inner_tuning_17.csv',index=False)
(ROOT/'ordinal_model_methodology.txt').write_text(__doc__ + '\nInner model choice minimizes pooled inner-held-out frequency MAE. For the training-selected-composite models, the four Hallmarks with highest positive training-only Spearman correlations are selected again within each inner training set; their fixed external-reference-standardized scores are averaged and subsequently standardized within training. The class labels are treated as equally spaced ordinal scores, which is a sensitivity analysis and not a principled proportional-odds fit. Outer study groups are never used for feature selection or tuning. Unseen lineage categories are represented by zeros. For rare classes (100kHz and 300kHz have one model each), balanced accuracy and threshold fitting are unstable. Original four-signature full-cohort composite is not used.\n')
