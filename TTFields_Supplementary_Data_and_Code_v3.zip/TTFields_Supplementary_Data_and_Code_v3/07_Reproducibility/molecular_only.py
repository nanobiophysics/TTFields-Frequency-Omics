"""Transparent reconstruction, not recovery of the unavailable original pipeline.
Run from project root: OPENBLAS_NUM_THREADS=1 python3 outputs/modeling_verified/reconstruct_modeling.py
No post hoc composite enters these models. 50 Hallmarks are candidates.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import json,zipfile,hashlib,platform,warnings
import numpy as np,pandas as pd,scipy,sklearn
from scipy.stats import rankdata,spearmanr
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge,LogisticRegression
from sklearn.metrics import mean_absolute_error,mean_squared_error,accuracy_score,balanced_accuracy_score,confusion_matrix
P=Path(__file__).resolve().parents[1]
OUT=P/'rerun'/'molecular_only';OUT.mkdir(parents=True,exist_ok=True)
supplied=pd.read_csv(P/'03_Predictive_Modeling/molecular_only_stage2/model17/analysis_input_17.csv')
cohort=supplied[['ModelID','CellLine','Frequency_kHz','Study']].copy()
raw=supplied.set_index('ModelID')
features=sorted(c for c in raw if c.startswith('HALLMARK_'))
assert len(features)==50 and cohort.ModelID.is_unique and len(cohort)==17
X=raw.loc[cohort.ModelID,features].to_numpy(float);y=cohort.Frequency_kHz.to_numpy(float);groups=cohort.Study.to_numpy()
assert np.isfinite(X).all() and len(set(groups))==12
pd.concat([cohort[['ModelID','CellLine','Frequency_kHz','Study']].reset_index(drop=True),pd.DataFrame(X,columns=features)],axis=1).to_csv(OUT/'analysis_input_17.csv',index=False)
# Fixed grids chosen before running the reconstruction. Larger regularization first breaks ties.
ks=[2,3,5,10,50]; penalties=[100,10,1,.1,.01]
def rank_features(x,t):
 rx=np.apply_along_axis(rankdata,0,x);rt=rankdata(t);rx-=rx.mean(0);rt-=rt.mean();den=np.sqrt((rx*rx).sum(0)*(rt*rt).sum());r=np.divide(rx.T@rt,den,out=np.zeros(x.shape[1]),where=den>0)
 return np.argsort(-np.abs(r),kind='stable')
def fit_predict(x,t,v,k,penalty,task):
 selected=rank_features(x,t)[:k]; scaler=StandardScaler().fit(x[:,selected]);a=scaler.transform(x[:,selected]);b=scaler.transform(v[:,selected])
 if task=='regression': model=Ridge(alpha=penalty)
 else:model=LogisticRegression(C=1/penalty,solver='lbfgs',max_iter=3000,tol=1e-7)
 model.fit(a,t);return model.predict(b),selected
all_metrics={};outfolds=[]
for task in ['regression','classification']:
 eligible=np.ones(len(y),bool) if task=='regression' else y!=300
 xx,yy,gg=X[eligible],y[eligible],groups[eligible]; meta=cohort.loc[eligible,['ModelID','CellLine','Frequency_kHz','Study']].reset_index(drop=True)
 pred=np.full(len(yy),np.nan);baseline=np.full(len(yy),np.nan);tuning=[];selections=[]
 for held in sorted(set(gg)):
  test=gg==held;train=~test;xt,yt,gt=xx[train],yy[train],gg[train]
  assert not set(gg[test])&set(gt)
  candidates=[]
  for k in ks:
   for penalty in penalties:
    ip=np.full(len(yt),np.nan)
    for inner in sorted(set(gt)):
     va=gt==inner;tr=~va
     assert not set(gt[tr])&set(gt[va]) and held not in set(gt)
     ip[va],_=fit_predict(xt[tr],yt[tr],xt[va],k,penalty,task)
    loss=mean_absolute_error(yt,ip) if task=='regression' else -balanced_accuracy_score(yt,ip)
    candidates.append((loss,k,penalty));tuning.append({'held_out_study':held,'k':k,'penalty':penalty,'inner_pooled_loss':loss})
  # Stable iteration order: smaller k then stronger penalty on numerical ties.
  best=min(candidates,key=lambda a:(round(a[0],12),a[1],-a[2]));_,k,penalty=best
  pred[test],selected=fit_predict(xt,yt,xx[test],k,penalty,task)
  if task=='regression': baseline[test]=np.median(yt)
  else:
   values,counts=np.unique(yt,return_counts=True);baseline[test]=values[np.argmax(counts)]
  for rank,j in enumerate(selected,1):selections.append({'held_out_study':held,'feature':features[j],'rank':rank})
  outfolds.append({'task':task,'held_out_study':held,'n_train':int(train.sum()),'n_test':int(test.sum()),'k':k,'penalty':penalty,'inner_pooled_loss':best[0]})
  print(task,held,'k',k,'penalty',penalty,flush=True)
 assert np.isfinite(pred).all() and np.isfinite(baseline).all()
 meta['prediction']=pred;meta['baseline_prediction']=baseline;meta.to_csv(OUT/f'{task}_predictions.csv',index=False)
 pd.DataFrame(tuning).to_csv(OUT/f'{task}_inner_search.csv',index=False)
 sel=pd.DataFrame(selections);sel.to_csv(OUT/f'{task}_selected_features.csv',index=False)
 sel.groupby('feature').size().sort_values(ascending=False).rename('folds_selected').to_csv(OUT/f'{task}_feature_recurrence.csv')
 metrics={}
 for name,pp in [('model',pred),('baseline',baseline)]:
  if task=='regression':
   rho,p=spearmanr(yy,pp) if np.ptp(pp)>0 else (np.nan,np.nan)
   grid=np.sort(np.unique(yy));near=grid[np.abs(pp[:,None]-grid).argmin(1)]
   m={'MAE_kHz':mean_absolute_error(yy,pp),'RMSE_kHz':np.sqrt(mean_squared_error(yy,pp)),'spearman_rho':float(rho),'spearman_p_descriptive':float(p),'nearest_grid_accuracy':float(np.mean(near==yy)),'within_50_kHz':float(np.mean(abs(pp-yy)<=50))}
   m['macro_study_MAE_kHz']=float(np.mean([mean_absolute_error(yy[gg==s],pp[gg==s]) for s in sorted(set(gg))]))
  else:
   m={'accuracy':accuracy_score(yy,pp),'balanced_accuracy':balanced_accuracy_score(yy,pp),'confusion_matrix_100_150_200':confusion_matrix(yy,pp,labels=[100,150,200]).tolist()}
  metrics[name]=m
 all_metrics[task]={'n':len(yy),'n_groups':len(set(gg)),'metrics':metrics}
pd.DataFrame(outfolds).to_csv(OUT/'outer_fold_audit.csv',index=False)
config={'status':'new transparent reconstruction; original code unavailable','group_variable':'Study in data/cohort_20_and_study_groups.csv, identical to modeling_code/analysis_input_20.csv; no regrouping','outer_cv':'leave one study group out','inner_cv':'leave one remaining study group out','candidate_features':features,'ranking':'absolute Spearman correlation with numeric frequency, fitted in each inner training split and refitted in outer training split','preprocessing':'StandardScaler fitted after selection in each training split; no imputation required; no reference-population scaling used','k_grid':ks,'ridge_alpha_grid':penalties,'logistic_C_grid':[1/x for x in penalties],'classification':'unweighted multinomial logistic regression, lbfgs, max_iter=3000, tol=1e-7; 300 kHz singleton excluded','selection_objective':'pooled inner held-out MAE for regression; pooled inner held-out balanced accuracy for classification','ties':'loss rounded to 12 decimals, then smaller k, then stronger regularization; class baseline ties choose lower frequency','baselines':'median or majority class from each outer training set only','primary_metrics':'pooled cell-line-level metrics; supplementary macro-study MAE','limitations':['group identifiers inherited from frozen cohort; source independence and annotation uncertainties remain','overlapping training folds make feature recurrence non-independent','no external validation','algorithm and grids chosen after earlier exploratory work; no prospective validation'],'versions':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__}}
def json_safe(value):
 if isinstance(value,dict):return {k:json_safe(v) for k,v in value.items()}
 if isinstance(value,list):return [json_safe(v) for v in value]
 if isinstance(value,float) and not np.isfinite(value):return None
 return value
(OUT/'configuration.json').write_text(json.dumps(config,indent=2));(OUT/'metrics.json').write_text(json.dumps(json_safe(all_metrics),indent=2,allow_nan=False));print(json.dumps(json_safe(all_metrics),indent=2,allow_nan=False))
