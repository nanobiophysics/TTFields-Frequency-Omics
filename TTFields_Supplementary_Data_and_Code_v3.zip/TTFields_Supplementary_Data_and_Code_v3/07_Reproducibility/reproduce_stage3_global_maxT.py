import numpy as np,pandas as pd,zipfile,io,json
from pathlib import Path
P=Path(__file__).resolve().parents[1]

from scipy.stats import rankdata
O=P/'rerun'/'study_lineage'
O.mkdir(parents=True, exist_ok=True)
a=pd.read_csv(P/'02_Primary_Cohort17/study_lineage_tests/cohort17_with_lineages.csv')
x=pd.read_csv(P/'01_Inputs_and_Provenance/candidate_rows_all_gene_sets.csv')
print('candidate',x.shape); print('missing IDs', set(a.ModelID)-set(x.ModelID));assert set(a.ModelID)<=set(x.ModelID)
X=x.set_index('ModelID').loc[a.ModelID]
cols=X.columns.to_list();assert len(cols)==31117
arr=X.to_numpy(float)
assert np.isfinite(arr).all()
R=rankdata(arr,axis=0);R-=R.mean(axis=0);n=np.linalg.norm(R,axis=0);assert (n>0).all();R/=n
# same two permutations
idx=a.index[a.CellLine=='DAOY'].item(); jdx=a.index[a.CellLine=='KNS42'].item()
y0=a.Frequency_kHz.to_numpy(float);y1=y0.copy();y1[idx],y1[jdx]=y1[jdx],y1[idx]
vals=[]
for y in [y0,y1]:
 rr=rankdata(y);rr-=rr.mean();rr/=np.linalg.norm(rr)
 vals.append(rr@R)
V=np.stack(vals)
mx=np.max(np.abs(V),axis=1)
obs=np.abs(V[0]);punadjusted=(np.abs(V)>=obs[None,:]-1e-12).mean(axis=0)
maxT=(mx[:,None]>=obs[None,:]-1e-12).mean(axis=0)
D=pd.DataFrame({'GeneSet':cols,'rho':V[0],'exact_p':punadjusted,'maxT_FWER_p':maxT});D.sort_values('rho',ascending=False).to_csv(O/'global_31117_exact_maxT_17.csv',index=False)
summary={'n_models':len(a),'n_gene_sets':len(cols),'n_admissible_assignments':2,'min_maxT_FWER_p':float(maxT.min()),'min_exact_p':float(punadjusted.min()),'max_abs_rho_by_allocation':mx.tolist(),'max_abs_global_rho_observed':float(mx[0]),'n_FWER_significant':int((maxT<.05).sum())}
(O/'global_exact_maxT_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));print(D.loc[D.GeneSet.str.contains('SPERMATOGENESIS|FILOPODIUM_ASSEMBLY')].to_string(index=False))
